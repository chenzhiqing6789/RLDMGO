%% 1. ׼�����������峬������Χ
% ����һ������ĳ������� cg(1��27)������ֻ��ʾ����ʵ�����Ż�������
% lb = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  5, 1e-4,0.5, 3e-3, 10, 0.1];
% ub = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 5, 3e-3,0.9, 1e-3,  20,   3];
% 
% 
% 
% lb = [1, 0, 1, 1, 1, 1,	0, 8,  34, 64, 116, 101,256,110, 255, 40, 120, 19,44,2,	26,	158, 0.00234586, 0.884538233, 0.000530496, 14, 2.1]
% 
% 
% lb2 = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  15, 1e-4,0.5, 3e-3, 10, 0.1];
% ub2 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 15, 3e-3,0.9, 1e-3,  20,   3];
% 
% lb3 = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  30, 1e-4,0.5, 3e-3, 10, 0.1];
% ub3 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 30, 3e-3,0.9, 1e-3,  20,   3];



% lb = [0, 0, 0, 0, 0, 0,	0, 7,  32, 64, 116, 101,256, 110, 255, 40, 120, 19,44, 2, 26, 5, 0.00234586, 0.884538233, 0.000530496, 14, 2.1];
% ub = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128, 128,256, 128, 256, 64, 128, 32,64, 2, 32, 5,   3e-3,       0.9,       1e-3,        20,   3];

lb = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  1, 1e-4,0.5, 1e-3, 10, 0.1];
ub = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 1, 3e-3,0.9, 3e-3, 20,   3];


% lb2 = [0, 0, 0, 0, 0, 0, 0, 7,  32, 64, 116, 101,256, 110, 255, 40, 120, 19,44, 2, 26, 10, 0.00234586, 0.884538233, 0.000530496, 14, 2.1];
% ub2 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128, 128,256, 128, 256, 64, 128, 32,64, 2, 32, 10,   3e-3,       0.9,         1e-3,      20,   3];


lb2 = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  1, 1e-4,0.5, 1e-3, 10, 0.1];
ub2 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 1, 3e-3,0.9, 3e-3, 20,   3];


% lb3 = [0, 0, 0, 0, 0, 0, 0, 7,  32, 64, 116, 101,256, 110, 255, 40, 120, 19,44, 2, 26, 50,  0.00234586, 0.884538233, 0.000530496, 14, 2.1];
% ub3 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128, 128,256, 128, 256, 64, 128, 32,64, 2, 32, 50,   3e-3,       0.9,         1e-3,       20,  3];
lb3 = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  1, 1e-4,0.5, 1e-3, 10, 0.1];
ub3 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 1, 3e-3,0.9, 3e-3, 20,   3];


S=104;

%% 2. ����ѵ���� augmentedImageDatastore
% --- ע�⣺����������� .mat �ļ���ı������� dspl �� trac
fn_dspl    = sprintf('trainData%d/dspl',S);
fn_dsplR   = sprintf('trainData%d/dsplRadial',S);
fn_trac    = sprintf('trainData%d/trac',S);
fn_tracR   = sprintf('trainData%d/tracRadial',S);
    
dsplDS = imageDatastore({fn_dspl,fn_dsplR},  'FileExtensions','.mat','ReadFcn',@load);
tracDS = imageDatastore({fn_trac,fn_tracR},  'FileExtensions','.mat','ReadFcn',@load);
    
 % Ԥ���䲢����
 numTrain = numel(dsplDS.Files);
% numTrain = 6;
dspl_array = zeros(S,S,2,numTrain,'single');
trac_array = zeros(S,S,2,numTrain,'single');
for i=1:numTrain
    tmp1 = load(dsplDS.Files{i}); dspl_array(:,:,:,i) = tmp1.dspl;
    tmp2 = load(tracDS.Files{i}); trac_array(:,:,:,i) = tmp2.trac;
end
    
augimdsTrain = augmentedImageDatastore([S S 2], dspl_array, trac_array);

%% 3. ������֤�� augmentedImageDatastore
val_dspl_path = 'C:/Users/11066/Desktop/DL-TFM-main1/DL-TFM-main1/test/generic/testData104/dspl/';

 
val_trac_path = 'C:/Users/11066/Desktop/DL-TFM-main1/DL-TFM-main1/test/generic/testData104/trac/';
val_dspl_files = dir(fullfile(val_dspl_path,'MLData*.mat'));
val_trac_files = dir(fullfile(val_trac_path,'MLData*.mat'));
numVal = numel(val_dspl_files);
    
val_dspl_array = zeros(S,S,2,numVal,'single');
val_trac_array = zeros(S,S,2,numVal,'single');
% �������Ҫ�߽����Σ���һ��������
val_brdx = cell(numVal,1);
val_brdy = cell(numVal,1);
    
for i=1:numVal
    tmp1 = load(fullfile(val_dspl_path,  val_dspl_files(i).name));
    tmp2 = load(fullfile(val_trac_path,  val_trac_files(i).name));
    val_dspl_array(:,:,:,i) = tmp1.dspl;
    val_trac_array(:,:,:,i) = tmp2.trac;
    if isfield(tmp2,'brdx'), val_brdx{i} = tmp2.brdx; end
    if isfield(tmp2,'brdy'), val_brdy{i} = tmp2.brdy; end
end
    
augimdsVal = augmentedImageDatastore([S S 2], val_dspl_array, val_trac_array);

if ~hasdata(augimdsVal)
    error('��֤���ݼ�Ϊ�գ��������ݼ���·��');
end


%% 3. RLSBO ������ (�����ֶ�����ÿ�׶εĲ���)
optimizer_option = struct();
optimizer_option.dim             = numel(lb);
optimizer_option.lb              = lb;
optimizer_option.ub              = ub;
optimizer_option.lb2             = lb2;
optimizer_option.ub2             = ub2;
optimizer_option.lb3             = lb3;
optimizer_option.ub3             = ub3;

%% 5. ���� Enhanced_SBO_CNN
%% 4. ���÷ּ��Ż��� RLSBO_CNN_Staged
[BestLocation, CNVG, bestNet, final_X3, final_Fitness3] = RLMGO_CNN_Staged( ...
    augimdsTrain, numTrain, ...
    augimdsVal,   numVal, ...
    val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
    optimizer_option ...
);

%% 5. ������
save('bestTracNet_Stagedfinal.mat','bestNet');
save('RLSBO_CNN_Staged_Result.mat','BestLocation','CNVG');
writematrix(BestLocation,'BestLocation_Staged.csv');
writematrix(CNVG',       'CNVG_Staged.csv'); % ת��һ�·���鿴

% --- �������룺��������Ҫ�󱣴� final_X3 �� final_Fitness3 ---
writematrix(final_X3,       'final_X3_Staged.csv');
writematrix(final_Fitness3, 'final_Fitness3_Staged.csv');

% =========================================================================
% ================ �µķּ��Ż������� RLSBO_CNN_Staged ====================
% =========================================================================

function [BestLocation, Overall_CNVG, bestNet3,final_X3, final_Fitness3] = RLMGO_CNN_Staged(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,optimizer_option)
    %% 1. ��ʼ��
    disp('Staged Enhanced SBO is now tackling your problem');
    tic;

    dim = optimizer_option.dim;
    lb  = optimizer_option.lb; 
    ub  = optimizer_option.ub;

    lb2  = optimizer_option.lb2; 
    ub2  = optimizer_option.ub2;

    lb3  = optimizer_option.lb3; 
    ub3  = optimizer_option.ub3;

    %% 2. ����Ŀ�꺯���İ�װ�� (Wrapper)
    fobj_wrapped = @(x) fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                              val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                              x, lb, ub);
    
    fobj_wrapped2 = @(x) fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                              val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                              x, lb2, ub2);
    fobj_wrapped3 = @(x) fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                              val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                              x, lb3, ub3);

     
    %% ======================= STAGE 1 =======================
    disp('--- Starting Stage 1: Broad Search ---');
    N1 = 5;
    Max_FEs1 = 5;
    fprintf('Population: %d, FEs: %d\n', N1, Max_FEs1);
    
    [best_pos1, CNVG1, final_X1, final_Fitness1,~] = Enhanced_MGO(N1, Max_FEs1, lb, ub, dim, fobj_wrapped);
    
    GlobalBestLocation = best_pos1;
    GlobalBestFitness = CNVG1(end);
    Overall_CNVG = CNVG1;

    %% ======================= STAGE 2 =======================
    disp('--- Starting Stage 2: Focused Search ---');
    N2 = 5;
    Max_FEs2 = 5;
    fprintf('Population: %d (Top %d from Stage 1), FEs: %d\n', N2, N2, Max_FEs2);

    % ɸѡ��ǰ10���ľ�Ӣ
    [~, sorted_indices] = sort(final_Fitness1);
    elite_indices = sorted_indices(1:N2);
    initial_X2 = final_X1(elite_indices, :);
    initial_Fitness2 = final_Fitness1(elite_indices);

    [best_pos2, CNVG2, final_X2, final_Fitness2,~] = Enhanced_MGO(N2, Max_FEs2, lb2, ub2, dim, fobj_wrapped2, initial_X2, initial_Fitness2);
    
    % ����ȫ�����Ž�
    if CNVG2(end) < GlobalBestFitness
        GlobalBestLocation = best_pos2;
        GlobalBestFitness = CNVG2(end);
    end
    Overall_CNVG = [Overall_CNVG, CNVG2];

    %% ======================= STAGE 3 =======================
    disp('--- Starting Stage 3: Elite Refinement ---');
    N3 = 5;
    Max_FEs3 = 5;
    fprintf('Population: %d (Top %d from Stage 2), FEs: %d\n', N3, N3, Max_FEs3);

    % ɸѡ��ǰ5���ľ�Ӣ
    [~, sorted_indices] = sort(final_Fitness2);
    elite_indices = sorted_indices(1:N3);
    initial_X3 = final_X2(elite_indices, :);
    initial_Fitness3 = final_Fitness2(elite_indices);

    [best_pos3, CNVG3, final_X3, final_Fitness3,bestNet3] = Enhanced_MGO(N3, Max_FEs3, lb3, ub3, dim, fobj_wrapped3, initial_X3, initial_Fitness3);

    % ����ȫ�����Ž�
    if CNVG3(end) < GlobalBestFitness
        GlobalBestLocation = best_pos3;
        GlobalBestFitness = CNVG3(end);
    end
    Overall_CNVG = [Overall_CNVG, CNVG3];
    
    BestLocation = GlobalBestLocation; % ���յ����λ��


    toc;
end


function [best_pos, Convergence_curve, current_X, current_Fitness,bestnet] = Enhanced_MGO(N, Max_FEs, lb, ub, dim, fobjj, initial_X, initial_Fitness)
    %INITIALIZATION
     % --- MODIFICATION ---
    % Now accepts optional initial_X and initial_Fitness
    % Also returns the final population (current_X, current_Fitness)
    bestnet = []; 
    Convergence_curve = [];
    FEs = 0;
    bestFitness=inf;
    
    % --- MODIFICATION: Conditional Initialization ---
    if nargin < 7 || isempty(initial_X)
        % Standard start: Randomly initialize and evaluate the population
        current_X = initialization(N, dim, ub, lb);
        current_Fitness = inf * ones(N, 1);
        for i = 1:N
            if FEs >= Max_FEs, break; end
            [current_Fitness(i, 1),net] = fobjj(current_X(i, :));
            FEs = FEs + 1;

            if current_Fitness(i,1) < bestFitness
                bestFitness = current_Fitness(i,1);
                bestnet = net; % ���µ�ǰ��õ�����
                save('bestTracNet_Staged.mat','bestnet');
            end
        end
    else
        % Staged start: Use the provided elite population
        current_X = initial_X;
        current_Fitness = initial_Fitness;

        [bestFitness, best_idx] = min(current_Fitness);
        best_pos = current_X(best_idx, :);
        Convergence_curve = bestFitness;
        if isempty(bestnet)
            [~, bestnet] = fobjj(best_pos);
            save('bestTracNet_Staged.mat','bestnet');
        end
        


        % FEs counter for this stage starts at 0
    end

    if FEs >= Max_FEs % Handle cases where initialization exceeds FEs
        [bestFitness, best_idx] = min(current_Fitness);
        best_pos = current_X(best_idx, :);
        Convergence_curve = bestFitness;
        if isempty(bestnet)
            [~, bestnet] = fobjj(best_pos);
            save('bestTracNet_Staged.mat','bestnet');
        end
        return;
    end
    
    [bestFitness, best_idx] = min(current_Fitness);
    best_pos = current_X(best_idx, :);


    %% --- ENHANCEMENT 1: Reinforcement Learning (RL) Setup ---
    % Action 1: Exploration (DE Operator)
    % Action 2: MGO search operator
    num_actions = 2; 
    Q_table = zeros(N, num_actions); % Q-table for each agent
    learning_rate = 0.5; % Alpha
    epsilon = 0.5; % Initial exploration rate for action selection
    
    %% --- ENHANCEMENT 2: DE Operator Parameter Setup (Non-Adaptive) ---
    memory_size = N;
    M_F = 0.5 * ones(memory_size, 1); % Memory for scaling factor F (now static)
    M_CR = 0.5 * ones(memory_size, 1); % Memory for crossover rate CR (now static)
    archive = []; % Archive for storing improved parent solutions
    archive_size_limit = 2 * N;
    p_best_rate = 0.1; % Percentage for selecting p-best individual
    
    %% --- MGO Algorithm Parameters (for Action 2) ---
    mgo_w = 2;
    mgo_divide_num = dim/4;
    mgo_d1 = 0.2;
     
	iter = 1;
    
    while FEs < Max_FEs
        
        %% --- MGO Pre-calculation for this generation (used if action 2 is chosen) ---
        calPositions = current_X;
        div_num = randperm(dim);
        
        % Divide the population based on the best solution
        for j = 1:max(floor(mgo_divide_num),1)
            th = best_pos(div_num(j));
            index = calPositions(:,div_num(j)) > th;
            if sum(index) < size(calPositions, 1)/2 % Choose the side of the majority
                index = ~index;
            end
            if sum(index) > 0 % Ensure calPositions is not empty
                calPositions = calPositions(index,:);
            end
        end
        
        % Compute the average distance vector D_wind
        D = best_pos - calPositions; 
        D_wind = sum(D, 1) / size(calPositions, 1);
        
        beta = size(calPositions, 1) / N;
        gama = 1 / sqrt(max(1e-10, 1 - power(beta, 2))); % Add small epsilon to avoid division by zero
        
        % Calculate MGO step sizes for this generation
        mgo_step = mgo_w * (rand(1, dim)-0.5) * (1-FEs/Max_FEs);
        mgo_step2 = 0.1 * mgo_w * (rand(1, dim)-0.5) * (1-FEs/Max_FEs) * (1 + 1/2 * (1 + tanh(beta/gama)) * (1-FEs/Max_FEs));
        mgo_step3 = 0.1 * (rand()-0.5) * (1-FEs/Max_FEs);
        mgo_act_input = 1 ./ (1 + (0.5 - 10*(rand(1, dim))));
        mgo_act = actCal(mgo_act_input);
        
        
        for i = 1:N
            %% --- RL: Action Selection (Epsilon-Greedy) ---
            if rand < epsilon
                action = randi(num_actions); % Explore: choose a random action
            else
                [~, action] = max(Q_table(i, :)); % Exploit: choose the best-known action
            end
            
            %% Generate Trial Vector based on the selected action
            trial_X = zeros(1, dim);
            
            if action == 1 % Action 1: Exploration (DE Operator)
                
                % Generate F and CR from static memory
                cr_idx = randi(memory_size);
                CR = normrnd(M_CR(cr_idx), 0.1);
                CR = min(1, max(0, CR));
            
                f_idx = randi(memory_size);
                F = -1;
                while F <= 0 % F must be positive
                    F = cauchy_rnd(M_F(f_idx), 0.1);
                end
                F = min(1, F);

                % Select pbest from top individuals
                p_best_count = max(2, ceil(p_best_rate * N));
                [~, sorted_indices] = sort(current_Fitness);
                pbest_idx = sorted_indices(randi(p_best_count));
                p_best_pos = current_X(pbest_idx, :);

                % Select r1 from population and r2 from archive
                r1_idx = randi(N); 
                while r1_idx == i, r1_idx = randi(N); end
                
                % Combine current population and archive for r2 selection
                pop_archive = [current_X; archive];
                r2_idx = randi(size(pop_archive, 1));
                while r2_idx == i, r2_idx = randi(size(pop_archive, 1)); end
                
                % Mutation: DE/current-to-pbest/1
                v = current_X(i, :) + F * (p_best_pos - current_X(i, :)) + F * (current_X(r1_idx, :) - pop_archive(r2_idx, :));

                % Binomial Crossover
                j_rand = randi(dim);
                for j = 1:dim
                    if rand < CR || j == j_rand
                        trial_X(j) = v(j);
                    else
                        trial_X(j) = current_X(i, j);
                    end
                end

            elseif action == 2 % Action 2: MGO search operator
                trial_X = current_X(i, :);
                
                % Spore dispersal search (from MGO)
                if rand() > mgo_d1
                    trial_X = trial_X + mgo_step .* D_wind; 
                else
                    trial_X = trial_X + mgo_step2 .* D_wind;
                end
                
                % Dual propagation search (from MGO)
                if rand() < 0.8
                    if rand() > 0.5
                        trial_X(div_num(1)) = best_pos(div_num(1)) + mgo_step3 * D_wind(div_num(1));
                    else
                        trial_X = (1 - mgo_act) .* trial_X + mgo_act .* best_pos;
                    end
                end
            end
            
            %% Boundary control
            trial_X = BoundaryControl(trial_X, lb, ub);
            
            %% Greedy Selection & Updates
%             trial_Fitness = fobj(trial_X);
            [trial_Fitness,net] = fobjj(trial_X);
            FEs = FEs + 1;
            
            if trial_Fitness < current_Fitness(i)
                % Success: update position and fitness
                old_solution = current_X(i, :);
                current_X(i, :) = trial_X;
                current_Fitness(i) = trial_Fitness;
                reward = 1; % Positive reward for improvement
                
                % Add the replaced parent to the archive (if DE action was used)
                if action == 1
                    archive(end+1, :) = old_solution;
                end
                
                % Update global best if necessary
                if trial_Fitness < bestFitness
                    bestFitness = trial_Fitness;
                    best_pos = trial_X;
                    bestnet=net;
                    save('bestTracNet_Staged.mat','bestnet')
                end
            else
                % Failure
                reward = 0; % No reward for no improvement
            end
            
            %% RL: Update Q-table
            Q_table(i, action) = (1 - learning_rate) * Q_table(i, action) + learning_rate * reward;
        end
        
        %% Trim archive if it exceeds the size limit
        if size(archive, 1) > archive_size_limit
            rand_indices = randperm(size(archive, 1));
            archive = archive(rand_indices(1:archive_size_limit), :);
        end
        
        Convergence_curve(iter) = bestFitness;
        iter = iter + 1;
        epsilon = epsilon * 0.95; % Decay epsilon over time
    end
end  

%% --- Helper Functions ---

    
function r = cauchy_rnd(mu, gamma)
    % Generates a random number from a Cauchy distribution
    r = mu + gamma * tan(pi * (rand - 0.5));
end

% --- Helper function from MGO ---
function [act] = actCal(X)
    act = X;
    act(act>=0.5) = 1;
    act(act<0.5) = 0;
end


%% --- Helper Functions ---

function X = initialization(N, dim, ub, lb)
    Boundary_no = size(ub, 2); % Number of boundaries
    if Boundary_no == 1
        X = rand(N, dim) .* (ub - lb) + lb;
    else
        X = zeros(N, dim);
        for i = 1:dim
            ub_i = ub(i);
            lb_i = lb(i);
            X(:,i) = rand(N,1).*(ub_i-lb_i)+lb_i;
        end
    end
end

function X = BoundaryControl(X, low, up)
    if numel(low) == 1 % Single boundary for all dimensions
        X(X < low) = low;
        X(X > up) = up;
    else % Boundary for each dimension
        X = max(X, low);
        X = min(X, up);
    end
end





% =========================================================================
% ============ Ŀ�꺯�� fobj1 (�����κ��޸�) ============================
% =========================================================================

function [fitness, net]=fobj1(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,cg,lb,ub)
    %% 1. ��ʼ��
    cg = max(min(cg,ub), lb);
    %% 1. �� cg ��ȡ���������
    % 1.1 attention ���أ�bool��
    encoder_att = logical( cg(1:3) > 0.5 );   % 3 �� encoder attention
    decoder_att = logical( cg(4:7) > 0.5 );   % 4 �� decoder attention
    ef = round( cg(8:13) );                   % 6 ����
    encoder_filters = reshape(ef, 3, 2);    % �� [ [f11 f12]; [f21 f22]; [f31 f32] ]
    
    % 1.3 decoder_filters��4��2 ��������
    df = round( cg(14:21) );                  % 8 ����
    decoder_filters = reshape(df, 4, 2);    % �� [ [d11 d12]; ... ; [d41 d42] ]
   
    % 1.4 ѵ������
    ep                   = max(1, round(cg(22)));  % ���� epoch ��1
    lr                   = cg(23);                  % ��ʼѧϰ�ʣ����㣩
    LearnRateDropFactor  = cg(24);                  % ѧϰ���½�����
    L2Regularization     = cg(25);                  % L2 ����ǿ��
    LearnRateDropPeriod  = ceil(cg(26));  % ��ѧϰ�����ڣ����� ��1��
    solverNum   = ceil(cg(27)) ; 

    params.encoder_att        = encoder_att;          % �߼��� 1��3
    params.decoder_att        = decoder_att;          % �߼��� 1��4
    params.encoder_filters    = encoder_filters;      % ���� 3��2
    params.decoder_filters    = decoder_filters;      % ���� 4��2
    params.epochs             = ep;                   % ������
    params.learning_rate      = lr;                   % ������
    params.lr_drop_factor     = LearnRateDropFactor;  % ������
    params.l2_reg             = L2Regularization;     % ������
    params.lr_drop_period     = LearnRateDropPeriod;  % ����
    params.solver_number      = solverNum;            % ����
        % �������������� fprintf ���
    fprintf('\n--- Evaluating New Hyperparameters ---\n');
    fprintf('  encoder_att: [%s]\n', num2str(params.encoder_att));
    fprintf('  decoder_att: [%s]\n', num2str(params.decoder_att));
    fprintf('  encoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d]\n', params.encoder_filters');
    fprintf('  decoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d; %d %d]\n', params.decoder_filters');
    fprintf('  epochs: %d\n', params.epochs);
    fprintf('  learning rate: %.4g\n', params.learning_rate);
    fprintf('  lr drop factor: %.4g\n', params.lr_drop_factor);
    fprintf('  L2 regularization: %.4g\n', params.l2_reg);
    fprintf('  lr drop period: %d\n', params.lr_drop_period);
    fprintf('  solver number: %d\n', params.solver_number);
    %% 2. �����볬������
    S = 104;
    solverList  = {'sgdm','sgdm','sgdm'}; % Note: Original code has 3 'sgdm'. Should be {'sgdm', 'adam', 'rmsprop'}?
    solverType = solverList{solverNum};
    
    % ��̬���������ͼ (���� createTracnet_optim2 ����������·����)
    lgraph = createTracnet_optim2(S, encoder_att, decoder_att, ...
                                  encoder_filters, decoder_filters);
    
    %% 5. ���� minibatch ����֤Ƶ��
    numTrainFiles = numTrain;  
    mag = S/104;
    MiniBatchSize      = ceil(40/mag);
    valFreq            = ceil(numTrainFiles/MiniBatchSize);

    % ���� solverType ѡ��ѵ��ѡ��
    switch lower(solverType)
       case 'sgdm'
          options = trainingOptions('sgdm', ...
                'InitialLearnRate',    lr, ...
                'LearnRateSchedule',   'piecewise', ...
                'LearnRateDropPeriod', LearnRateDropPeriod, ...
                'LearnRateDropFactor', LearnRateDropFactor, ...
                'L2Regularization',    L2Regularization, ...
                'MaxEpochs',           ep, ...
                'MiniBatchSize',       MiniBatchSize, ...
                'Shuffle',             'every-epoch', ...
                'GradientThreshold',   1, ...
                'Verbose',             1, ... % ���ı����
                'Plots',               'training-progress'); % ��ѵ������ͼ

    
      case 'adam'
          options = trainingOptions('adam', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'Verbose',             0, ...
            'Plots',               'none');
    
      case 'rmsprop'
            options = trainingOptions('rmsprop', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'Verbose',             0, ...
            'Plots',               'none');
    
      otherwise
        error('Unsupported solver type: %s', solverType);
    end
    
    %% 7. ��ʼѵ��
    try
        [net, ~] = trainNetwork(augimdsTrain, lgraph, options);
    catch ME
        fprintf('!!! Training failed for the current hyperparameter set: %s\n', ME.message);
        % ���ѵ��ʧ�� (��������ṹ��������Ϸ�)������һ���������Ӧ��ֵ
        fitness = inf; 
        net = []; % û����������
        return;
    end
    
    %% 8. ��ѵ���õ������� net ����֤������һ����������
    totalErr = 0;
    E = 10670;    % �� predictTrac �б���һ�µ��������
    
    for i=1:numVal
        dsplSample = val_dspl_array(:,:,:,i);
        tracGT     = val_trac_array(:,:,:,i);
        brdx       = [];
        brdy       = [];
        if ~isempty(val_brdx{i}), brdx = val_brdx{i}; end
        if ~isempty(val_brdy{i}), brdy = val_brdy{i}; end
    
        pred = predictTrac(net, dsplSample, E);
        % ���û���ṩ�߽磬����ֱ�� errorTrac(pred,tracGT)��
        % ����� brdx,brdy ����ȥ�� interior masking
        if isempty(brdx) || isempty(brdy)
            totalErr = totalErr + errorTrac_no_boundary(pred, tracGT);
        else
            totalErr = totalErr + errorTrac(pred, tracGT, brdx, brdy);
        end
    end
    
    meanErr = totalErr / numVal;
    fprintf('�� Fitness (Mean Relative Error): %.6f\n', meanErr);
    fitness = meanErr;
end

%% ����Ԥ��������㺯�� (������һ���ޱ߽�İ汾������³����)
function trac = predictTrac(net, dspl, E)
    S = size(dspl,1);
    mag = S/104;
    conversion = E/10*mag;
    trac = activations(net,dspl,'output')*conversion;
end

function errorT = errorTrac(trac,tracGT,brdx,brdy,varargin)
    % (����ԭʼ errorTrac �����������޸�)
    warning('off','all');
    if nargin==4
        cutoff = 0;
    elseif nargin==5
        cutoff = varargin{1};
    else
        disp('Error')
    end
    pgn = polyshape(brdx,brdy);
    [ydim,xdim,~] = size(trac);
    [X,Y] = meshgrid(1:xdim,1:ydim);
    interior = isinterior(pgn,Y(:),X(:));
    interior = reshape(interior,ydim,xdim);

    trac(:,:,1) = trac(:,:,1).*interior;
    trac(:,:,2) = trac(:,:,2).*interior;
    tracGT(:,:,1) = tracGT(:,:,1).*interior;
    tracGT(:,:,2) = tracGT(:,:,2).*interior;

    tracMag = sqrt(trac(:,:,1).^2+trac(:,:,2).^2);
    tracGTMag = sqrt(tracGT(:,:,1).^2+tracGT(:,:,2).^2);

    if cutoff>0
        threshold = prctile(tracGTMag(interior),cutoff);
        I = tracMag>threshold | tracGTMag>threshold;
        trac(:,:,1) = trac(:,:,1).*I;
        trac(:,:,2) = trac(:,:,2).*I;
        tracGT(:,:,1) = tracGT(:,:,1).*I;
        tracGT(:,:,2) = tracGT(:,:,2).*I;
    else
        I = ones(ydim,xdim);
    end

    mse = sum((trac(:,:,1)-tracGT(:,:,1)).^2 + (trac(:,:,2)-tracGT(:,:,2)).^2,'all')/nnz(interior.*I);
    rmse = sqrt(mse);
    msm = sum(tracGT(:,:,1).^2+tracGT(:,:,2).^2,'all')/nnz(interior.*I);
    rmsm = sqrt(msm);
    errorT = rmse/rmsm;
end


function lgraph = createTracnet_optim2(S, encoder_att, decoder_att, encoder_filters, decoder_filters)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% createTracnet(S, [encoder_att], [decoder_att])
% ��С�Ķ��汾������ע�������ؿ���
% encoder_att: [1��3 logical] ���������׶��Ƿ��ע���� (Ĭ��ȫtrue)
% decoder_att: [1��4 logical] ���������׶��Ƿ��ע���� (Ĭ��ȫtrue)

%% ���������Դ���������ԭ�е��÷�ʽ��
if nargin < 2, encoder_att = true(1,3); end
if nargin < 3, decoder_att = true(1,4); end

if nargin < 4 || isempty(encoder_filters)  % ����Ĭ�ϱ���������
    encoder_filters = [32 64; 64 128; 128 256]; 
end
if nargin < 5 || isempty(decoder_filters)  % ����Ĭ�Ͻ���������
    decoder_filters = [128 256; 64 128; 32 64; 1 32];
end

%% ԭʼ�������ñ��ֲ���
inputSize = [S S 2];
inputLayer = image3dInputLayer(inputSize,'Normalization','none','Name','input');
numFiltersEncoder = encoder_filters;
layers = [inputLayer];

%% �Ľ���1��������ģ������������
encoder_outputs = cell(3,1); % ��¼������������ڵ�
decoder_outputs = cell(4,1);
for module = 1:3
    layer_name = num2str(module);
    encoderModule = [
        convolution3dLayer([3 3 2], numFiltersEncoder(module,1), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['en', layer_name, '_conv1']);
        batchNormalizationLayer('Name', ['en', layer_name, '_bn']);
        reluLayer('Name', ['en', layer_name, '_relu1']);
        convolution3dLayer([3 3 2], numFiltersEncoder(module,2), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['en', layer_name, '_conv2']);
        reluLayer('Name', ['en', layer_name, '_relu2'])
    ];

    %%% ��������ע����ģ�� %%%
    if encoder_att(module)
        encoderModule = [encoderModule;
            globalAveragePooling3dLayer('Name', ['en', layer_name, '_gap']);
            fullyConnectedLayer(numFiltersEncoder(module,2), 'Name', ['en', layer_name, '_fc1']);
            reluLayer('Name', ['en', layer_name, '_relu3']);
            fullyConnectedLayer(numFiltersEncoder(module,2), 'Name', ['en', layer_name, '_fc2']);
            sigmoidLayer('Name', ['en', layer_name, '_sigmoid1']);
            multiplicationLayer(2, 'Name', ['en', layer_name, '_channel_mult']);
            
            convolution3dLayer([3 3 3], 1, 'Padding', 'same', 'Name', ['en', layer_name, '_spatial_conv']);
            sigmoidLayer('Name', ['en', layer_name, '_sigmoid2']);
            multiplicationLayer(2, 'Name', ['en', layer_name, '_spatial_mult'])
        ];
        encoder_outputs{module} = "en" + layer_name + "_spatial_mult"; % �ַ�������
    else
         encoder_outputs{module} = "en" + layer_name + "_relu2"; 
    end

    encoderModule = [encoderModule;
        maxPooling3dLayer([2,2,1], 'Stride', [2,2,1], 'Padding', 'same', ...
            'Name', ['en', layer_name, '_maxpool'])
    ];
    layers = [layers; encoderModule];
end

%% �Ľ���2��������ģ������������
numFiltersDecoder = decoder_filters;
for module = 1:4
    layer_name = num2str(-module+5);
    decodeModule = [
        convolution3dLayer([3 3 2], numFiltersDecoder(module,1), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['de', layer_name, '_conv1']);
        batchNormalizationLayer('Name', ['de', layer_name, '_bn1']);
        reluLayer('Name', ['de', layer_name, '_relu1']);
        convolution3dLayer([3 3 2], numFiltersDecoder(module,2), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['de', layer_name, '_conv2']);
        batchNormalizationLayer('Name', ['de', layer_name, '_bn2']);        
        reluLayer('Name', ['de', layer_name, '_relu2'])
    ];


    %%% �޸��㣺���н���������ǰ׺��Ϊde %%%
    if decoder_att(module)
        decodeModule = [decodeModule;
            globalAveragePooling3dLayer('Name', ['de', layer_name, '_gap']);
            fullyConnectedLayer(numFiltersDecoder(module,2), 'Name', ['de', layer_name, '_fc1']);
            reluLayer('Name', ['de', layer_name, '_relu3']);
            fullyConnectedLayer(numFiltersDecoder(module,2), 'Name', ['de', layer_name, '_fc2']);
            sigmoidLayer('Name', ['de', layer_name, '_sigmoid1']);
            multiplicationLayer(2, 'Name', ['de', layer_name, '_channel_mult']);
            
            convolution3dLayer([3 3 3], 1, 'Padding', 'same', 'Name', ['de', layer_name, '_spatial_conv']);
            sigmoidLayer('Name', ['de', layer_name, '_sigmoid2']);
            multiplicationLayer(2, 'Name', ['de', layer_name, '_spatial_mult'])
        ];
        decoder_outputs{module} = "de" + layer_name + "_spatial_mult"; % �ؼ��޸���
    else
        decoder_outputs{module} = "de" + layer_name + "_relu2"; 
    end

    decodeModule = [decodeModule;
        transposedConv3dLayer([3,3,1], numFiltersDecoder(module,2), 'Stride', [2,2,1], 'Cropping', 'same', ...
            'WeightsInitializer', 'narrow-normal', 'BiasInitializer', 'zeros', ...
            'Name', ['de', layer_name, '_transconv'])
    ];
    
    layers = [layers; decodeModule];
end






lgraph = layerGraph(layers);

lgraph = removeLayers(lgraph, 'de1_transconv');
layer =  convolution3dLayer([3 3 2], 1, ...
            'Padding','same','WeightsInitializer','narrow-normal', ...
            'BiasInitializer', 'zeros', ...
            'Name',['de1_conv3']);
lgraph = addLayers(lgraph,layer);
if decoder_att(4)
   lgraph = connectLayers(lgraph,'de1_spatial_mult','de1_conv3');
else
   lgraph = connectLayers(lgraph,'de1_relu2','de1_conv3');
end
layer = regressionLayer('name','output');
lgraph = addLayers(lgraph,layer);
lgraph = connectLayers(lgraph, 'de1_conv3','output');
for module = 1:3
    
    
     if encoder_att(module)
          layer_name = num2str(module);
          lgraph = connectLayers(lgraph, ['en', layer_name, '_relu2'], ['en', layer_name, '_channel_mult/in2']); 
          lgraph = connectLayers(lgraph, ['en', layer_name, '_channel_mult'], ['en', layer_name, '_spatial_mult/in2']);
     end
  
end

%% �Ľ���4��������ע�����������������޸��棩
for module = 1:4
    layer_name = num2str(-module+5);
    
    % �������ø�ģ���ע����ʱ��ִ������
    if decoder_att(module)
        % 遍历�?有编码器和解码器模块
        %% ͨ��ע��������
        channel_src = ['de', layer_name, '_relu2'];
        channel_dest = ['de', layer_name, '_channel_mult/in2'];
        if ~hasConnection(lgraph, channel_src, channel_dest)
            lgraph = connectLayers(lgraph, channel_src, channel_dest);
        end
        
        %% �ռ�ע��������
        spatial_src = ['de', layer_name, '_channel_mult'];
        spatial_dest = ['de', layer_name, '_spatial_mult/in2'];
        if ~hasConnection(lgraph, spatial_src, spatial_dest)
            lgraph = connectLayers(lgraph, spatial_src, spatial_dest);
        end
    end
end

%% �������������������ļ�ĩβ��
function existFlag = hasConnection(lgraph, src, dest)
% ���ָ�������Ƿ��Ѵ���
   existFlag = any(strcmp(lgraph.Connections.Source, src) & ...
                strcmp(lgraph.Connections.Destination, dest));
end


concat_config = [ % ��Ϊ��ά�ַ�������
    "en1", "concat1/in1", "de2_transconv"; 
    "en2", "concat2/in1", "de3_transconv"; 
    "en3", "concat3/in1", "de4_transconv"
];

for i = 1:3
    % ֱ�Ӱ�����������
    concat_name = concat_config(i,1);
    in_port = concat_config(i,2);
    deconv_layer = concat_config(i,3);
    
    % ͳһʹ���ַ���ƴ��
    lgraph = disconnectLayers(lgraph, deconv_layer, "de" + i + "_conv1");
    concat_layer = concatenationLayer(4,2,'Name',char(concat_name)); % ת��Ϊchar
    lgraph = addLayers(lgraph, concat_layer);
    lgraph = connectLayers(lgraph, encoder_outputs{i}, concat_name + "/in1");
    lgraph = connectLayers(lgraph, deconv_layer, concat_name + "/in2");
    lgraph = connectLayers(lgraph, concat_name + "/out", "de" + i + "_conv1");
end

%% ����ԭʼ���������߼�
analyzeNetwork(lgraph);
fn = sprintf('tracnetGraph%d_AttEnc%d%d%d_Dec%d%d%d%d.mat',S,...
    encoder_att(1),encoder_att(2),encoder_att(3),...
    decoder_att(1),decoder_att(2),decoder_att(3),decoder_att(4));
save(fn,'lgraph');
end





