% 启用注意力
createTracnet(104)
% createTracnet_optim2(104, [1 1 1], [1 1 1 0])
% % % 自定义过滤器配置（示例：增大网络容量）
% custom_encoder = [1 1;    % 编码器第1阶段
%                  1 1;    % 编码器第2阶段
%                  1 1];   % 编码器第3阶段
%                  
% custom_decoder = [1 1;   % 解码器第1阶段
%                  1 1;    % 解码器第2阶段
%                  1 1;     % 解码器第3阶段
%                  1 1];      % 解码器第4阶段
%                  
% createTracnet_optim2(104, [1 1 1], [1 1 1 1], custom_encoder, custom_decoder)