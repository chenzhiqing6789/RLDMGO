%% 1. ׼�����������峬������Χ
% ����һ������ĳ������� cg(1��27)������ֻ��ʾ����ʵ�����Ż�������
lb = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  5, 1e-4,0.5, 3e-3, 10, 0.1];
ub = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 5, 3e-3,0.9, 1e-3,  20,   3];

lb2 = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  15, 1e-4,0.5, 3e-3, 10, 0.1];
ub2 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 15, 3e-3,0.9, 1e-3,  20,   3];

lb3 = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  30, 1e-4,0.5, 3e-3, 10, 0.1];
ub3 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 30, 3e-3,0.9, 1e-3,  20,   3];

S=104;

%% 2. ����ѵ���� augmentedImageDatastore
% --- ע�⣺����������� .mat �ļ���ı������� dspl �� trac
fn_dspl    = sprintf('trainData%d/dspl',S);
fn_dsplR   = sprintf('trainData%d/dsplRadial',S);
fn_trac    = sprintf('trainData%d/trac',S);
fn_tracR   = sprintf('trainData%d/tracRadial',S);
    
dsplDS = imageDatastore({fn_dspl,fn_dsplR},  'FileExtensions','.mat','ReadFcn',@load);
tracDS = imageDatastore({fn_trac,fn_tracR},  'FileExtensions','.mat','ReadFcn',@load);
    
 % Ԥ���䲢����
numTrain = numel(dsplDS.Files);
dspl_array = zeros(S,S,2,numTrain,'single');
trac_array = zeros(S,S,2,numTrain,'single');
for i=1:numTrain
    tmp1 = load(dsplDS.Files{i}); dspl_array(:,:,:,i) = tmp1.dspl;
    tmp2 = load(tracDS.Files{i}); trac_array(:,:,:,i) = tmp2.trac;
end
    
augimdsTrain = augmentedImageDatastore([S S 2], dspl_array, trac_array);

%% 3. ������֤�� augmentedImageDatastore
val_dspl_path = 'C:/Users/11066/Desktop/DL-TFM-main1/test/generic/testData104/dspl/';
val_trac_path = 'C:/Users/11066/Desktop/DL-TFM-main1/test/generic/testData104/trac/';
val_dspl_files = dir(fullfile(val_dspl_path,'MLData*.mat'));
val_trac_files = dir(fullfile(val_trac_path,'MLData*.mat'));
numVal = numel(val_dspl_files);
    
val_dspl_array = zeros(S,S,2,numVal,'single');
val_trac_array = zeros(S,S,2,numVal,'single');
% �������Ҫ�߽����Σ���һ��������
val_brdx = cell(numVal,1);
val_brdy = cell(numVal,1);
    
for i=1:numVal
    tmp1 = load(fullfile(val_dspl_path,  val_dspl_files(i).name));
    tmp2 = load(fullfile(val_trac_path,  val_trac_files(i).name));
    val_dspl_array(:,:,:,i) = tmp1.dspl;
    val_trac_array(:,:,:,i) = tmp2.trac;
    if isfield(tmp2,'brdx'), val_brdx{i} = tmp2.brdx; end
    if isfield(tmp2,'brdy'), val_brdy{i} = tmp2.brdy; end
end
    
augimdsVal = augmentedImageDatastore([S S 2], val_dspl_array, val_trac_array);

if ~hasdata(augimdsVal)
    error('��֤���ݼ�Ϊ�գ��������ݼ���·��');
end


%% 3. RLSBO ������ (�����ֶ�����ÿ�׶εĲ���)
optimizer_option = struct();
optimizer_option.dim             = numel(lb);
optimizer_option.lb              = lb;
optimizer_option.ub              = ub;
optimizer_option.lb2             = lb2;
optimizer_option.ub2             = ub2;
optimizer_option.lb3             = lb3;
optimizer_option.ub3             = ub3;

%% 5. ���� Enhanced_SBO_CNN
%% 4. ���÷ּ��Ż��� RLSBO_CNN_Staged
[BestLocation, CNVG, bestNet,final_X3, final_Fitness3] = RLSBO_CNN_Staged( ...
    augimdsTrain, numTrain, ...
    augimdsVal,   numVal, ...
    val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
    optimizer_option ...
);

%% 5. ������
save('bestTracNet_Staged.mat','bestNet');
save('RLSBO_CNN_Staged_Result.mat','BestLocation','CNVG');
writematrix(BestLocation,'BestLocation_Staged.csv');
writematrix(CNVG',       'CNVG_Staged.csv'); % ת��һ�·���鿴

% --- �������룺��������Ҫ�󱣴� final_X3 �� final_Fitness3 ---
writematrix(final_X3,       'final_X3_Staged.csv');
writematrix(final_Fitness3, 'final_Fitness3_Staged.csv');

% =========================================================================
% ================ �µķּ��Ż������� RLSBO_CNN_Staged ====================
% =========================================================================

function [BestLocation, Overall_CNVG, bestNet,final_X3, final_Fitness3] = RLSBO_CNN_Staged(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,optimizer_option)
    %% 1. ��ʼ��
    disp('Staged Enhanced SBO is now tackling your problem');
    tic;

    dim = optimizer_option.dim;
    lb  = optimizer_option.lb; 
    ub  = optimizer_option.ub;

    lb2  = optimizer_option.lb2; 
    ub2  = optimizer_option.ub2;

    lb3  = optimizer_option.lb3; 
    ub3  = optimizer_option.ub3;

    %% 2. ����Ŀ�꺯���İ�װ�� (Wrapper)
    fobj_wrapped = @(x) fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                              val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                              x, lb, ub);
    
    fobj_wrapped2 = @(x) fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                              val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                              x, lb2, ub2);
    fobj_wrapped3 = @(x) fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                              val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                              x, lb3, ub3);

     
    %% ======================= STAGE 1 =======================
    disp('--- Starting Stage 1: Broad Search ---');
    N1 = 20;
    Max_FEs1 = 100;
    fprintf('Population: %d, FEs: %d\n', N1, Max_FEs1);
    
    [best_pos1, CNVG1, final_X1, final_Fitness1] = Enhanced_SBO(N1, Max_FEs1, lb, ub, dim, fobj_wrapped);
    
    GlobalBestLocation = best_pos1;
    GlobalBestFitness = CNVG1(end);
    Overall_CNVG = CNVG1;

    %% ======================= STAGE 2 =======================
    disp('--- Starting Stage 2: Focused Search ---');
    N2 = 10;
    Max_FEs2 = 20;
    fprintf('Population: %d (Top %d from Stage 1), FEs: %d\n', N2, N2, Max_FEs2);

    % ɸѡ��ǰ10���ľ�Ӣ
    [~, sorted_indices] = sort(final_Fitness1);
    elite_indices = sorted_indices(1:N2);
    initial_X2 = final_X1(elite_indices, :);
    initial_Fitness2 = final_Fitness1(elite_indices);

    [best_pos2, CNVG2, final_X2, final_Fitness2] = Enhanced_SBO(N2, Max_FEs2, lb2, ub2, dim, fobj_wrapped2, initial_X2, initial_Fitness2);
    
    % ����ȫ�����Ž�
    if CNVG2(end) < GlobalBestFitness
        GlobalBestLocation = best_pos2;
        GlobalBestFitness = CNVG2(end);
    end
    Overall_CNVG = [Overall_CNVG, CNVG2];

    %% ======================= STAGE 3 =======================
    disp('--- Starting Stage 3: Elite Refinement ---');
    N3 = 5;
    Max_FEs3 = 10;
    fprintf('Population: %d (Top %d from Stage 2), FEs: %d\n', N3, N3, Max_FEs3);

    % ɸѡ��ǰ5���ľ�Ӣ
    [~, sorted_indices] = sort(final_Fitness2);
    elite_indices = sorted_indices(1:N3);
    initial_X3 = final_X2(elite_indices, :);
    initial_Fitness3 = final_Fitness2(elite_indices);

    [best_pos3, CNVG3, final_X3, final_Fitness3] = Enhanced_SBO(N3, Max_FEs3, lb3, ub3, dim, fobj_wrapped3, initial_X3, initial_Fitness3);

    % ����ȫ�����Ž�
    if CNVG3(end) < GlobalBestFitness
        GlobalBestLocation = best_pos3;
        GlobalBestFitness = CNVG3(end);
    end
    Overall_CNVG = [Overall_CNVG, CNVG3];
    
    BestLocation = GlobalBestLocation; % ���յ����λ��

    %% 4. ��ȡ�����λ�ö�Ӧ������ģ��
    disp('Staged optimization finished. Retraining the best model...');
    fprintf('Final Best Fitness: %.6f\n', GlobalBestFitness);
    [~, bestNet] = fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                         val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                         BestLocation, lb, ub);
    toc;
end


function [best_pos, Convergence_curve, current_X, current_Fitness] = Enhanced_SBO(N, Max_FEs, lb, ub, dim, fobj, initial_X, initial_Fitness)
    % --- MODIFICATION ---
    % Now accepts optional initial_X and initial_Fitness
    % Also returns the final population (current_X, current_Fitness)

    Convergence_curve = [];
    FEs = 0;
    
    % --- MODIFICATION: Conditional Initialization ---
    if nargin < 7 || isempty(initial_X)
        % Standard start: Randomly initialize and evaluate the population
        current_X = initialization(N, dim, ub, lb);
        current_Fitness = inf * ones(N, 1);
        for i = 1:N
            if FEs >= Max_FEs, break; end
            current_Fitness(i, 1) = fobj(current_X(i, :));
            FEs = FEs + 1;
        end
    else
        % Staged start: Use the provided elite population
        current_X = initial_X;
        current_Fitness = initial_Fitness;
        % FEs counter for this stage starts at 0
    end

    if FEs >= Max_FEs % Handle cases where initialization exceeds FEs
        [bestFitness, best_idx] = min(current_Fitness);
        best_pos = current_X(best_idx, :);
        Convergence_curve = bestFitness;
        return;
    end
    
    [bestFitness, best_idx] = min(current_Fitness);
    best_pos = current_X(best_idx, :);
    
    % --- The rest of the algorithm remains the same ---
    num_actions = 2; 
    Q_table = zeros(N, num_actions); 
    learning_rate = 0.5; 
%     discount_factor = 0.9; 
    epsilon = 0.5; 
    memory_size = N; 
    M_F = 0.5 * ones(memory_size, 1); 
    M_CR = 0.5 * ones(memory_size, 1); 
    mu_F = 0.5; 
    mu_CR = 0.5;
    archive = []; 
    archive_size_limit = 2 * N; 
    k = 1;

	iter = 1;
    
    while FEs < Max_FEs
        S_F = []; 
        S_CR = [];
        archive = [archive; current_X];
        if size(archive, 1) > archive_size_limit
            rand_indices = randperm(size(archive, 1));
            archive = archive(rand_indices(1:archive_size_limit), :);
        end
        for i = 1:N
            if FEs >= Max_FEs
                break; 
            end

            if rand < epsilon 
                action = randi(num_actions); 
            else
                [~, action] = max(Q_table(i, :)); 
            end

            cr_idx = randi(memory_size); 
            CR = normrnd(M_CR(cr_idx), 0.1); 
            CR = min(1, max(0, CR));
            f_idx = randi(memory_size); 
            F = -1; 
            while F <= 0 
                F = cauchy_rnd(M_F(f_idx), 0.1); 
            end 
            F = min(1, F);
            trial_X = zeros(1, dim);
            if action == 1
                p = 0.1; 
                p_best_count = max(2, ceil(p*N)); 
                [~, sorted_indices] = sort(current_Fitness); 
                pbest_idx = sorted_indices(randi(p_best_count)); 
                p_best_pos = current_X(pbest_idx, :);
                r1_idx = randi(N); 
                while r1_idx == i
                    r1_idx = randi(N); 
                end
                r2_idx = randi(size(archive, 1)); 
                while r2_idx == i
                    r2_idx = randi(size(archive, 1)); 
                end
                v = current_X(i, :) + F * (p_best_pos - current_X(i, :)) + F * (current_X(r1_idx, :) - archive(r2_idx, :));
                j_rand = randi(dim);
                for j = 1:dim
                    if rand < CR || j == j_rand
                        trial_X(j) = v(j); 
                    else 
                        trial_X(j) = current_X(i, j); 
                    end 
                end
            else
                Rolette_index = RouletteWheelSelection(1./current_Fitness); 
                if Rolette_index == -1
                    Rolette_index = best_idx; 
                end
                r1 = randn; 
                r2 = randn; 
                r3 = tanh((sqrt(abs(Max_FEs - randn * FEs))/iter)^(FEs/Max_FEs));
                for j = 1:dim
                    trial_X(j) = (1 - r1 - r2) * current_X(i, j) + r1 * current_X(Rolette_index, j) + r2 * best_pos(j); 
                    if rand > r3
                        trial_X(j) = trial_X(j) * r3 * randn; 
                    end
                end
            end
            trial_X = BoundaryControl(trial_X, lb, ub);
            trial_Fitness = fobj(trial_X);
            FEs = FEs + 1;
           
            if trial_Fitness < current_Fitness(i)
                current_X(i, :) = trial_X; 
                current_Fitness(i) = trial_Fitness; 
                reward = 1;
                if action == 1
                    S_F(end+1) = F; 
                    S_CR(end+1) = CR; 
                end
                if trial_Fitness < bestFitness
                    bestFitness = trial_Fitness; 
                    best_pos = trial_X; 
                end
            else
                reward = 0; 

            end
            Q_table(i, action) = (1 - learning_rate) * Q_table(i, action) + learning_rate * reward;
        end
        if ~isempty(S_F)
            mu_F = (sum(S_F.^2) / sum(S_F)); 
            M_F(k) = mu_F; 
        end
        if ~isempty(S_CR)
            mu_CR = mean(S_CR); 
            M_CR(k) = mu_CR; 
        end
        k = k + 1; 
        if k > memory_size
            k = 1; 
        end

        Convergence_curve(iter) = bestFitness;
        fprintf('Stage Iter: %d, Stage FEs: %d/%d, Current Best Fitness: %.6f\n', iter, FEs, Max_FEs, bestFitness);
        iter = iter + 1;
        epsilon = epsilon * 0.9;
    end
end  



%% --- Helper Functions for Enhanced_SBO ---

function X = initialization(N, dim, ub, lb)
    Boundary_no = size(ub, 2); % Number of boundaries
    if Boundary_no == 1
        X = rand(N, dim) .* (ub - lb) + lb;
    else
        X = zeros(N, dim);
        for i = 1:N
            for j = 1:dim
                X(i, j) = rand .* (ub(j) - lb(j)) + lb(j);
            end
        end
    end
end

function X = BoundaryControl(X, low, up)
    [~, dim] = size(X);
    if numel(low) == 1 % Single boundary for all dimensions
        X(X < low) = low;
        X(X > up) = up;
    else % Boundary for each dimension
        for j=1:dim
            if X(j) < low(j), X(j) = low(j); end
            if X(j) > up(j), X(j) = up(j); end
        end
    end
end
    
function choice = RouletteWheelSelection(weights)
  weights(isinf(weights)) = 1e10; % Handle potential inf from 1/0
  weights(isnan(weights)) = 1e-10;
  if sum(weights) == 0
      choice = -1;
      return;
  end
  accumulation = cumsum(weights);
  if accumulation(end) == 0
      choice = -1;
      return;
  end
  p = rand() * accumulation(end);
  chosen_index = -1;
  for index = 1:length(accumulation)
    if (accumulation(index) > p)
      chosen_index = index;
      break;
    end
  end
  choice = chosen_index;
end  

function r = cauchy_rnd(mu, gamma)
    % Generates a random number from a Cauchy distribution
    r = mu + gamma * tan(pi * (rand - 0.5));
end



% =========================================================================
% ============ Ŀ�꺯�� fobj1 (�����κ��޸�) ============================
% =========================================================================

function [fitness, net]=fobj1(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,cg,lb,ub)
    %% 1. ��ʼ��
    cg = max(min(cg,ub), lb);
    %% 1. �� cg ��ȡ���������
    % 1.1 attention ���أ�bool��
    encoder_att = logical( cg(1:3) > 0.5 );   % 3 �� encoder attention
    decoder_att = logical( cg(4:7) > 0.5 );   % 4 �� decoder attention
    ef = round( cg(8:13) );                   % 6 ����
    encoder_filters = reshape(ef, 3, 2);    % �� [ [f11 f12]; [f21 f22]; [f31 f32] ]
    
    % 1.3 decoder_filters��4��2 ��������
    df = round( cg(14:21) );                  % 8 ����
    decoder_filters = reshape(df, 4, 2);    % �� [ [d11 d12]; ... ; [d41 d42] ]
   
    % 1.4 ѵ������
    ep                   = max(1, round(cg(22)));  % ���� epoch ��1
    lr                   = cg(23);                  % ��ʼѧϰ�ʣ����㣩
    LearnRateDropFactor  = cg(24);                  % ѧϰ���½�����
    L2Regularization     = cg(25);                  % L2 ����ǿ��
    LearnRateDropPeriod  = ceil(cg(26));  % ��ѧϰ�����ڣ����� ��1��
    solverNum   = ceil(cg(27)) ; 

    params.encoder_att        = encoder_att;          % �߼��� 1��3
    params.decoder_att        = decoder_att;          % �߼��� 1��4
    params.encoder_filters    = encoder_filters;      % ���� 3��2
    params.decoder_filters    = decoder_filters;      % ���� 4��2
    params.epochs             = ep;                   % ������
    params.learning_rate      = lr;                   % ������
    params.lr_drop_factor     = LearnRateDropFactor;  % ������
    params.l2_reg             = L2Regularization;     % ������
    params.lr_drop_period     = LearnRateDropPeriod;  % ����
    params.solver_number      = solverNum;            % ����
        % �������������� fprintf ���
    fprintf('\n--- Evaluating New Hyperparameters ---\n');
    fprintf('  encoder_att: [%s]\n', num2str(params.encoder_att));
    fprintf('  decoder_att: [%s]\n', num2str(params.decoder_att));
    fprintf('  encoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d]\n', params.encoder_filters');
    fprintf('  decoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d; %d %d]\n', params.decoder_filters');
    fprintf('  epochs: %d\n', params.epochs);
    fprintf('  learning rate: %.4g\n', params.learning_rate);
    fprintf('  lr drop factor: %.4g\n', params.lr_drop_factor);
    fprintf('  L2 regularization: %.4g\n', params.l2_reg);
    fprintf('  lr drop period: %d\n', params.lr_drop_period);
    fprintf('  solver number: %d\n', params.solver_number);
    %% 2. �����볬������
    S = 104;
    solverList  = {'sgdm','sgdm','sgdm'}; % Note: Original code has 3 'sgdm'. Should be {'sgdm', 'adam', 'rmsprop'}?
    solverType = solverList{solverNum};
    
    % ��̬���������ͼ (���� createTracnet_optim2 ����������·����)
    lgraph = createTracnet_optim2(S, encoder_att, decoder_att, ...
                                  encoder_filters, decoder_filters);
    
    %% 5. ���� minibatch ����֤Ƶ��
    numTrainFiles = numTrain;  
    mag = S/104;
    MiniBatchSize      = ceil(20/mag);
    valFreq            = ceil(numTrainFiles/MiniBatchSize);

    % ���� solverType ѡ��ѵ��ѡ��
    switch lower(solverType)
       case 'sgdm'
           options = trainingOptions('sgdm', ...
                'InitialLearnRate',    lr, ...
                'LearnRateSchedule',   'piecewise', ...
                'LearnRateDropPeriod', LearnRateDropPeriod, ...
                'LearnRateDropFactor', LearnRateDropFactor, ...
                'L2Regularization',    L2Regularization, ...
                'MaxEpochs',           ep, ...
                'MiniBatchSize',       MiniBatchSize, ...
                'Shuffle',             'every-epoch', ...
                'GradientThreshold',   1, ...
                'Verbose',             0, ... % �رՆ��µ�ѵ�����
                'Plots',               'none'); % �ر�ѵ������ͼ
    
      case 'adam'
          options = trainingOptions('adam', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'Verbose',             0, ...
            'Plots',               'none');
    
      case 'rmsprop'
            options = trainingOptions('rmsprop', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'Verbose',             0, ...
            'Plots',               'none');
    
      otherwise
        error('Unsupported solver type: %s', solverType);
    end
    
    %% 7. ��ʼѵ��
    try
        [net, ~] = trainNetwork(augimdsTrain, lgraph, options);
    catch ME
        fprintf('!!! Training failed for the current hyperparameter set: %s\n', ME.message);
        % ���ѵ��ʧ�� (��������ṹ��������Ϸ�)������һ���������Ӧ��ֵ
        fitness = inf; 
        net = []; % û����������
        return;
    end
    
    %% 8. ��ѵ���õ������� net ����֤������һ����������
    totalErr = 0;
    E = 10670;    % �� predictTrac �б���һ�µ��������
    
    for i=1:numVal
        dsplSample = val_dspl_array(:,:,:,i);
        tracGT     = val_trac_array(:,:,:,i);
        brdx       = [];
        brdy       = [];
        if ~isempty(val_brdx{i}), brdx = val_brdx{i}; end
        if ~isempty(val_brdy{i}), brdy = val_brdy{i}; end
    
        pred = predictTrac(net, dsplSample, E);
        % ���û���ṩ�߽磬����ֱ�� errorTrac(pred,tracGT)��
        % ����� brdx,brdy ����ȥ�� interior masking
        if isempty(brdx) || isempty(brdy)
            totalErr = totalErr + errorTrac_no_boundary(pred, tracGT);
        else
            totalErr = totalErr + errorTrac(pred, tracGT, brdx, brdy);
        end
    end
    
    meanErr = totalErr / numVal;
    fprintf('�� Fitness (Mean Relative Error): %.6f\n', meanErr);
    fitness = meanErr;
end

%% ����Ԥ��������㺯�� (������һ���ޱ߽�İ汾������³����)
function trac = predictTrac(net, dspl, E)
    S = size(dspl,1);
    mag = S/104;
    conversion = E/10*mag;
    trac = activations(net,dspl,'output')*conversion;
end

function errorT = errorTrac(trac,tracGT,brdx,brdy,varargin)
    % (����ԭʼ errorTrac �����������޸�)
    warning('off','all');
    if nargin==4
        cutoff = 0;
    elseif nargin==5
        cutoff = varargin{1};
    else
        disp('Error')
    end
    pgn = polyshape(brdx,brdy);
    [ydim,xdim,~] = size(trac);
    [X,Y] = meshgrid(1:xdim,1:ydim);
    interior = isinterior(pgn,Y(:),X(:));
    interior = reshape(interior,ydim,xdim);

    trac(:,:,1) = trac(:,:,1).*interior;
    trac(:,:,2) = trac(:,:,2).*interior;
    tracGT(:,:,1) = tracGT(:,:,1).*interior;
    tracGT(:,:,2) = tracGT(:,:,2).*interior;

    tracMag = sqrt(trac(:,:,1).^2+trac(:,:,2).^2);
    tracGTMag = sqrt(tracGT(:,:,1).^2+tracGT(:,:,2).^2);

    if cutoff>0
        threshold = prctile(tracGTMag(interior),cutoff);
        I = tracMag>threshold | tracGTMag>threshold;
        trac(:,:,1) = trac(:,:,1).*I;
        trac(:,:,2) = trac(:,:,2).*I;
        tracGT(:,:,1) = tracGT(:,:,1).*I;
        tracGT(:,:,2) = tracGT(:,:,2).*I;
    else
        I = ones(ydim,xdim);
    end

    mse = sum((trac(:,:,1)-tracGT(:,:,1)).^2 + (trac(:,:,2)-tracGT(:,:,2)).^2,'all')/nnz(interior.*I);
    rmse = sqrt(mse);
    msm = sum(tracGT(:,:,1).^2+tracGT(:,:,2).^2,'all')/nnz(interior.*I);
    rmsm = sqrt(msm);
    errorT = rmse/rmsm;
end




