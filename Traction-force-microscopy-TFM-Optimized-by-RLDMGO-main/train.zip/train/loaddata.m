% =========================================================================
% 功能: 使用经典的 U-Net 模型，训练一个从单通道明场图像预测双通道力场的
%       回归任务。
%       - 集成了经典 U-Net 的创建、数据加载、划分和训练的全过程。
% 作者: AI Assistant (根据用户需求修改)
% 日期: 2023-10-27 (U-Net 回归版, 最终修正 v2)
% =========================================================================

function train_UNet_regression_guaranteed_final() % 最终版主函数

    clear;
    clc;
    close all;

    %% --- 1. 设置路径和参数 ---
    % ... (此部分代码完全正确，无需修改) ...
    baseDir = 'C:\Users\admin\Desktop\Dataset1\label';
    labelFileName = 'forceField_unstructured.mat'; 
    trainRatio = 0.9;

    %% --- 2. 扫描文件并创建图像-标签路径对 ---
    % ... (此部分代码完全正确，无需修改) ...
    fprintf('开始扫描文件并创建数据对...\n');
    if ~isfolder(baseDir), error('基础路径 "%s" 不存在，请仔细检查！', baseDir); end
    filePairs = table('Size', [0 2], 'VariableTypes', {'string', 'string'}, 'VariableNames', {'ImagePath', 'LabelPath'});
    dirContents = dir(baseDir);
    subFolders = dirContents([dirContents.isdir]);
    subFolders = subFolders(~ismember({subFolders.name}, {'.', '..'}));
    for i = 1:length(subFolders)
        currentFolderName = subFolders(i).name;
        currentSubDir = fullfile(baseDir, currentFolderName);
        labelFilePath = fullfile(currentSubDir, labelFileName);
        if ~isfile(labelFilePath), warning('在文件夹 %s 中未找到标签文件 %s，已跳过。', currentFolderName, labelFileName); continue; end
        imageFiles = dir(fullfile(currentSubDir, '*.tif'));
        for j = 1:length(imageFiles)
            imageFilePath = fullfile(currentSubDir, imageFiles(j).name);
            newRow = {imageFilePath, labelFilePath};
            filePairs = [filePairs; newRow];
        end
    end
    if isempty(filePairs), error('未能找到任何有效的图像-标签对。'); else, fprintf('扫描完成！总共找到了 %d 个图像-标签数据对。\n\n', height(filePairs)); end

    %% --- 3. 随机划分数据集 ---
    % ... (此部分代码完全正确，无需修改) ...
    fprintf('正在将数据划分为训练集和测试集 (9:1)...\n');
    numTotalPairs = height(filePairs);
    shuffledIndices = randperm(numTotalPairs);
    shuffledPairs = filePairs(shuffledIndices, :);
    numTrain = floor(trainRatio * numTotalPairs);
    trainPairs = shuffledPairs(1:numTrain, :);
    testPairs = shuffledPairs(numTrain+1 : end, :);
    fprintf('划分完成！训练集: %d, 测试集: %d\n\n', height(trainPairs), height(testPairs));

    %% --- 4. 准备训练和测试数据 (Data Preparation) ---
    % ... (此部分代码完全正确，无需修改) ...
    fprintf('正在准备训练和测试数据...\n');
    imgSize   = [512, 512, 1];
    labelSize = [512, 512, 2];
    numTrain = height(trainPairs);
    XTrain = zeros([imgSize, numTrain], 'single');
    YTrain = zeros([labelSize, numTrain], 'single');
    for i = 1:numTrain
        I = imread(trainPairs.ImagePath(i));
        XTrain(:,:,1,i) = im2single(I);
        tmp = load(trainPairs.LabelPath(i));
        YTrain(:,:,:,i) = single(tmp.force_matrix);
    end
    fprintf('训练数据准备完毕。\n');
    numTest = height(testPairs);
    XTest = zeros([imgSize, numTest], 'single');
    YTest = zeros([labelSize, numTest], 'single');
    for i = 1:numTest
        I = imread(testPairs.ImagePath(i));
        XTest(:,:,1,i) = im2single(I);
        tmp = load(testPairs.LabelPath(i));
        YTest(:,:,:,i) = single(tmp.force_matrix);
    end
    fprintf('测试数据准备完毕。\n\n');

    %% --- 5. 创建 Datastore (版本兼容) ---
    % ... (此部分代码完全正确，无需修改) ...
    fprintf('正在创建 Datastore...\n');
    dsXTrain = arrayDatastore(XTrain, 'IterationDimension', 4);
    dsYTrain = arrayDatastore(YTrain, 'IterationDimension', 4);
    combinedTrain = combine(dsXTrain, dsYTrain);
    dsXTest = arrayDatastore(XTest, 'IterationDimension', 4);
    dsYTest = arrayDatastore(YTest, 'IterationDimension', 4);
    combinedTest = combine(dsXTest, dsYTest);
    fprintf('Datastore 创建完毕。\n\n');

    %% --- 6. 创建经典 U-Net 网络结构 ---
    fprintf('正在创建经典 U-Net 网络...\n');
    lgraph = createUNet_foolproof([512 512 1], 2); % <--- 调用最终修正的函数
    fprintf('网络创建成功。\n\n');
    % analyzeNetwork(lgraph);

    %% --- 7. 训练参数 ---
    % ... (此部分代码完全正确，无需修改) ...
    ep = 300; 
    lr = 1e-3; 
    miniBatchSize = 20;
    options = trainingOptions('adam', 'InitialLearnRate', lr, 'LearnRateSchedule', 'piecewise', 'LearnRateDropPeriod', 5, 'LearnRateDropFactor', 0.8, 'L2Regularization', 0.0001, 'MaxEpochs', ep, 'MiniBatchSize', miniBatchSize, 'Shuffle', 'every-epoch', 'ValidationData', combinedTest, 'ValidationFrequency', floor(numTrain/miniBatchSize), 'Verbose', true, 'Plots', 'training-progress', 'ExecutionEnvironment', 'auto');

    %% --- 8. 开始训练 ---
    fprintf('开始训练网络...\n');
    [net, info] = trainNetwork(combinedTrain, lgraph, options);
    fprintf('训练完成！\n');

    %% --- 9. （可选）在测试集上评估 ---
    % ... (此部分代码完全正确，无需修改) ...
    YPred = predict(net, XTest);
    mse_error_matrix = (YPred - YTest).^2;
    final_mse = mean(mse_error_matrix(:));
    fprintf('在测试集上的最终均方误差 (MSE): %f\n', final_mse);

    %% --- 10. 保存训练好的网络 ---
    % ... (此部分代码完全正确，无需修改) ...
    outNetFn = sprintf('UNet_512x512_trained.mat');
    save(outNetFn, 'net', 'info');
    fprintf('训练好的网络已保存为: %s\n', outNetFn);

end


% =========================================================================
%           本地函数：创建经典 U-Net (最终修正的构建逻辑)
% =========================================================================
function lgraph = createUNet_foolproof(inputSize, numOutputChannels)
    
    % --- 1. 创建一个空的 Layer Graph ---
    lgraph = layerGraph;
    
    % --- 2. 定义并添加所有的层块 (Layers Blocks) ---
    % 这里的每个块都是一个线性的层序列
    
    % --- 编码器 ---
    encoderBlock1 = [
        imageInputLayer(inputSize, 'Name', 'input', 'Normalization', 'none')
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv1_1')
        reluLayer('Name', 'relu1_1')
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv1_2')
        reluLayer('Name', 'relu1_2_skip') % Skip connection source
    ];
    encoderBlock2 = [
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
        convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv2_1')
        reluLayer('Name', 'relu2_1')
        convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv2_2')
        reluLayer('Name', 'relu2_2_skip') % Skip connection source
    ];
    encoderBlock3 = [
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
        convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'conv3_1')
        reluLayer('Name', 'relu3_1')
        convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'conv3_2')
        reluLayer('Name', 'relu3_2_skip') % Skip connection source
    ];
    
    % --- 桥接 ---
    bridgeBlock = [
        maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool3')
        convolution2dLayer(3, 512, 'Padding', 'same', 'Name', 'conv4_1')
        reluLayer('Name', 'relu4_1')
        convolution2dLayer(3, 512, 'Padding', 'same', 'Name', 'conv4_2')
        reluLayer('Name', 'relu4_2')
    ];
    
    % --- 解码器 ---
    % 注意：这里将转置卷积、拼接层、和后续卷积分成了不同的块
    decoderBlock1_Upsample = transposedConv2dLayer(2, 256, 'Stride', 2, 'Cropping', 'same', 'Name', 'upconv1');
    decoderBlock1_Concat = concatenationLayer(3, 2, 'Name', 'concat1');
    decoderBlock1_Conv = [
        convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'deconv1_1')
        reluLayer('Name', 'derelu1_1')
        convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'deconv1_2')
        reluLayer('Name', 'derelu1_2')
    ];

    decoderBlock2_Upsample = transposedConv2dLayer(2, 128, 'Stride', 2, 'Cropping', 'same', 'Name', 'upconv2');
    decoderBlock2_Concat = concatenationLayer(3, 2, 'Name', 'concat2');
    decoderBlock2_Conv = [
        convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'deconv2_1')
        reluLayer('Name', 'derelu2_1')
        convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'deconv2_2')
        reluLayer('Name', 'derelu2_2')
    ];
    
    decoderBlock3_Upsample = transposedConv2dLayer(2, 64, 'Stride', 2, 'Cropping', 'same', 'Name', 'upconv3');
    decoderBlock3_Concat = concatenationLayer(3, 2, 'Name', 'concat3');
    decoderBlock3_Conv = [
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'deconv3_1')
        reluLayer('Name', 'derelu3_1')
        convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'deconv3_2')
        reluLayer('Name', 'derelu3_2')
    ];

    % --- 输出 ---
    outputBlock = [
        convolution2dLayer(1, numOutputChannels, 'Name', 'final_conv')
        regressionLayer('Name', 'output')
    ];
    
    % --- 将所有块添加到图中 ---
    lgraph = addLayers(lgraph, encoderBlock1);
    lgraph = addLayers(lgraph, encoderBlock2);
    lgraph = addLayers(lgraph, encoderBlock3);
    lgraph = addLayers(lgraph, bridgeBlock);
    lgraph = addLayers(lgraph, decoderBlock1_Upsample);
    lgraph = addLayers(lgraph, decoderBlock1_Concat);
    lgraph = addLayers(lgraph, decoderBlock1_Conv);
    lgraph = addLayers(lgraph, decoderBlock2_Upsample);
    lgraph = addLayers(lgraph, decoderBlock2_Concat);
    lgraph = addLayers(lgraph, decoderBlock2_Conv);
    lgraph = addLayers(lgraph, decoderBlock3_Upsample);
    lgraph = addLayers(lgraph, decoderBlock3_Concat);
    lgraph = addLayers(lgraph, decoderBlock3_Conv);
    lgraph = addLayers(lgraph, outputBlock);
    
    % --- 3. 手动连接所有块 ---
    
    % 连接编码器
    lgraph = connectLayers(lgraph, 'relu1_2_skip', 'pool1');
    lgraph = connectLayers(lgraph, 'relu2_2_skip', 'pool2');
    lgraph = connectLayers(lgraph, 'relu3_2_skip', 'pool3');
    
    % 连接桥接
    lgraph = connectLayers(lgraph, 'relu4_2', 'upconv1');
    
    % 连接解码器 1
    lgraph = connectLayers(lgraph, 'upconv1', 'concat1/in1');
    lgraph = connectLayers(lgraph, 'relu3_2_skip', 'concat1/in2'); % Skip connection
    lgraph = connectLayers(lgraph, 'concat1', 'deconv1_1');
    
    % 连接解码器 2
    lgraph = connectLayers(lgraph, 'derelu1_2', 'upconv2');
    lgraph = connectLayers(lgraph, 'upconv2', 'concat2/in1');
    lgraph = connectLayers(lgraph, 'relu2_2_skip', 'concat2/in2'); % Skip connection
    lgraph = connectLayers(lgraph, 'concat2', 'deconv2_1');
    
    % 连接解码器 3
    lgraph = connectLayers(lgraph, 'derelu2_2', 'upconv3');
    lgraph = connectLayers(lgraph, 'upconv3', 'concat3/in1');
    lgraph = connectLayers(lgraph, 'relu1_2_skip', 'concat3/in2'); % Skip connection
    lgraph = connectLayers(lgraph, 'concat3', 'deconv3_1');
    
    % 连接输出
    lgraph = connectLayers(lgraph, 'derelu3_2', 'final_conv');
    
end
