% --- DEFINE THIS CLASS AT THE END OF YOUR SCRIPT OR IN A SEPARATE .M FILE ---
classdef ChannelwiseMultiplicationLayer < nnet.layer.Layer
    % A custom layer that performs element-wise multiplication with broadcasting.
    % This is more robust than the standard multiplicationLayer for attention mechanisms
    % within a dlnetwork custom training loop.

    methods
        function layer = ChannelwiseMultiplicationLayer(Name)
            % Set layer name.
            layer.Name = Name;
            layer.Description = "Element-wise multiplication with broadcasting support";
        end
        
        function Z = predict(layer, X1, X2)
            % X1 is the feature map (e.g., HxWxCxB)
            % X2 is the attention weights (e.g., 1x1xCxB)
            % The '.*' operator on dlarray handles broadcasting automatically.
            Z = X1 .* X2;
        end
    end
end
