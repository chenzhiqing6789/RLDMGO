%% 1. ׼�����������峬������Χ
% ����һ������ĳ������� cg(1��27)������ֻ��ʾ����ʵ�����Ż�������
lb = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  1, 1e-4,0.5, 3e-3, 10, 0.1];
ub = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 1, 3e-3,0.9, 1e-3,  20,   3];
S=104;

%% 2. ����ѵ���� augmentedImageDatastore
% --- ע�⣺����������� .mat �ļ���ı������� dspl �� trac
fn_dspl    = sprintf('trainData%d/dspl',S);
fn_dsplR   = sprintf('trainData%d/dsplRadial',S);
fn_trac    = sprintf('trainData%d/trac',S);
fn_tracR   = sprintf('trainData%d/tracRadial',S);
    
dsplDS = imageDatastore({fn_dspl,fn_dsplR},  'FileExtensions','.mat','ReadFcn',@load);
tracDS = imageDatastore({fn_trac,fn_tracR},  'FileExtensions','.mat','ReadFcn',@load);
    
 % Ԥ���䲢����
numTrain = numel(dsplDS.Files);
dspl_array = zeros(S,S,2,numTrain,'single');
trac_array = zeros(S,S,2,numTrain,'single');
for i=1:numTrain
    tmp1 = load(dsplDS.Files{i}); dspl_array(:,:,:,i) = tmp1.dspl;
    tmp2 = load(tracDS.Files{i}); trac_array(:,:,:,i) = tmp2.trac;
end
    
augimdsTrain = augmentedImageDatastore([S S 2], dspl_array, trac_array);

%% 3. ������֤�� augmentedImageDatastore
val_dspl_path = 'C:/Users/11066/Desktop/DL-TFM-main1/test/generic/testData104/dspl/';
val_trac_path = 'C:/Users/11066/Desktop/DL-TFM-main1/test/generic/testData104/trac/';
val_dspl_files = dir(fullfile(val_dspl_path,'MLData*.mat'));
val_trac_files = dir(fullfile(val_trac_path,'MLData*.mat'));
numVal = numel(val_dspl_files);
    
val_dspl_array = zeros(S,S,2,numVal,'single');
val_trac_array = zeros(S,S,2,numVal,'single');
% �������Ҫ�߽����Σ���һ��������
val_brdx = cell(numVal,1);
val_brdy = cell(numVal,1);
    
for i=1:numVal
    tmp1 = load(fullfile(val_dspl_path,  val_dspl_files(i).name));
    tmp2 = load(fullfile(val_trac_path,  val_trac_files(i).name));
    val_dspl_array(:,:,:,i) = tmp1.dspl;
    val_trac_array(:,:,:,i) = tmp2.trac;
    if isfield(tmp2,'brdx'), val_brdx{i} = tmp2.brdx; end
    if isfield(tmp2,'brdy'), val_brdy{i} = tmp2.brdy; end
end
    
augimdsVal = augmentedImageDatastore([S S 2], val_dspl_array, val_trac_array);

if ~hasdata(augimdsVal)
    error('��֤���ݼ�Ϊ�գ��������ݼ���·��');
end

%% 4. Enhanced_SBO ������
optimizer_option = struct();
optimizer_option.SearchAgents_no = 5;    % ��Ⱥ��С (N)���Ƽ� 5��20
% --- ע�⣺���㷨ʹ���������������(Max_FEs)��Ϊֹͣ����
optimizer_option.Max_FEs         = 20;   % ���� 5�ε��� * 20��Ⱥ = 100������
optimizer_option.dim             = numel(lb);  % 27
optimizer_option.lb              = lb;
optimizer_option.ub              = ub;

%% 5. ���� Enhanced_SBO_CNN
% --- ���ú����Ѵ� HHO_CNN ����Ϊ Enhanced_SBO_CNN ---
[BestLocation, CNVG, bestNet] = RLSBO_CNN( ...
    augimdsTrain, numTrain, ...
    augimdsVal,   numVal, ...
    val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
    optimizer_option ...
);

%% 6. ������
save('bestTracNet_SBO.mat','bestNet');
save('Enhanced_SBO_CNN_Result.mat','BestLocation','CNVG');
writematrix(BestLocation,'BestLocation_SBO.csv');
writematrix(CNVG,        'CNVG_SBO.csv');


% =========================================================================
% ======================= �µ��Ż��������� ================================
% =========================================================================

function [BestLocation, CNVG, bestNet] = RLSBO_CNN(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,optimizer_option)
    %% 1. ��ʼ��
    disp('Enhanced SBO is now tackling your problem');
    tic;

    N      = optimizer_option.SearchAgents_no; 
    dim    = optimizer_option.dim;
    Max_FEs = optimizer_option.Max_FEs;
    lb     = optimizer_option.lb; 
    ub     = optimizer_option.ub;

    %% 2. ����Ŀ�꺯���İ�װ�� (Wrapper)
    % Enhanced_SBO �㷨��Ҫһ�� f(x) ��ʽ��Ŀ�꺯����
    % ����ʹ���������������б�������� "��װ" ��ȥ��
    % fobj1 ���� [fitness, net]���Ż������Զ�ʹ�õ�һ����� (fitness)��
    fobj_wrapped = @(x) fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                              val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                              x, lb, ub);

    %% 3. ���� Enhanced_SBO �����㷨
    [BestLocation, CNVG] = Enhanced_SBO(N, Max_FEs, lb, ub, dim, fobj_wrapped);
    
    %% 4. ��ȡ�����λ�ö�Ӧ������ģ��
    % �Ż���ֻ������ѵĲ���(BestLocation)��������Ҫ���������������һ��
    % fobj1 �����ѵ���õ�����ģ��(bestNet)��
    disp('Optimization finished. Retraining the best model...');
    [~, bestNet] = fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                         val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                         BestLocation, lb, ub);

    toc;
end


% =========================================================================
% ============ Ŀ�꺯�� fobj1 (�����κ��޸�) ============================
% =========================================================================

function [fitness, net]=fobj1(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,cg,lb,ub)
    %% 1. ��ʼ��
    cg = max(min(cg,ub), lb);
    %% 1. �� cg ��ȡ���������
    % 1.1 attention ���أ�bool��
    encoder_att = logical( cg(1:3) > 0.5 );   % 3 �� encoder attention
    decoder_att = logical( cg(4:7) > 0.5 );   % 4 �� decoder attention
    ef = round( cg(8:13) );                   % 6 ����
    encoder_filters = reshape(ef, 3, 2);    % �� [ [f11 f12]; [f21 f22]; [f31 f32] ]
    
    % 1.3 decoder_filters��4��2 ��������
    df = round( cg(14:21) );                  % 8 ����
    decoder_filters = reshape(df, 4, 2);    % �� [ [d11 d12]; ... ; [d41 d42] ]
   
    % 1.4 ѵ������
    ep                   = max(1, round(cg(22)));  % ���� epoch ��1
    lr                   = cg(23);                  % ��ʼѧϰ�ʣ����㣩
    LearnRateDropFactor  = cg(24);                  % ѧϰ���½�����
    L2Regularization     = cg(25);                  % L2 ����ǿ��
    LearnRateDropPeriod  = ceil(cg(26));  % ��ѧϰ�����ڣ����� ��1��
    solverNum   = ceil(cg(27)) ; 

    params.encoder_att        = encoder_att;          % �߼��� 1��3
    params.decoder_att        = decoder_att;          % �߼��� 1��4
    params.encoder_filters    = encoder_filters;      % ���� 3��2
    params.decoder_filters    = decoder_filters;      % ���� 4��2
    params.epochs             = ep;                   % ������
    params.learning_rate      = lr;                   % ������
    params.lr_drop_factor     = LearnRateDropFactor;  % ������
    params.l2_reg             = L2Regularization;     % ������
    params.lr_drop_period     = LearnRateDropPeriod;  % ����
    params.solver_number      = solverNum;            % ����
        % �������������� fprintf ���
    fprintf('\n--- Evaluating New Hyperparameters ---\n');
    fprintf('  encoder_att: [%s]\n', num2str(params.encoder_att));
    fprintf('  decoder_att: [%s]\n', num2str(params.decoder_att));
    fprintf('  encoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d]\n', params.encoder_filters');
    fprintf('  decoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d; %d %d]\n', params.decoder_filters');
    fprintf('  epochs: %d\n', params.epochs);
    fprintf('  learning rate: %.4g\n', params.learning_rate);
    fprintf('  lr drop factor: %.4g\n', params.lr_drop_factor);
    fprintf('  L2 regularization: %.4g\n', params.l2_reg);
    fprintf('  lr drop period: %d\n', params.lr_drop_period);
    fprintf('  solver number: %d\n', params.solver_number);
    %% 2. �����볬������
    S = 104;
    solverList  = {'sgdm','sgdm','sgdm'}; % Note: Original code has 3 'sgdm'. Should be {'sgdm', 'adam', 'rmsprop'}?
    solverType = solverList{solverNum};
    
    % ��̬���������ͼ (���� createTracnet_optim2 ����������·����)
    lgraph = createTracnet_optim2(S, encoder_att, decoder_att, ...
                                  encoder_filters, decoder_filters);
    
    %% 5. ���� minibatch ����֤Ƶ��
    numTrainFiles = numTrain;  
    mag = S/104;
    MiniBatchSize      = ceil(20/mag);
    valFreq            = ceil(numTrainFiles/MiniBatchSize);

    % ���� solverType ѡ��ѵ��ѡ��
    switch lower(solverType)
       case 'sgdm'
           options = trainingOptions('sgdm', ...
                'InitialLearnRate',    lr, ...
                'LearnRateSchedule',   'piecewise', ...
                'LearnRateDropPeriod', LearnRateDropPeriod, ...
                'LearnRateDropFactor', LearnRateDropFactor, ...
                'L2Regularization',    L2Regularization, ...
                'MaxEpochs',           ep, ...
                'MiniBatchSize',       MiniBatchSize, ...
                'Shuffle',             'every-epoch', ...
                'GradientThreshold',   1, ...
                'Verbose',             0, ... % �رՆ��µ�ѵ�����
                'Plots',               'none'); % �ر�ѵ������ͼ
    
      case 'adam'
          options = trainingOptions('adam', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'Verbose',             0, ...
            'Plots',               'none');
    
      case 'rmsprop'
            options = trainingOptions('rmsprop', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'Verbose',             0, ...
            'Plots',               'none');
    
      otherwise
        error('Unsupported solver type: %s', solverType);
    end
    
    %% 7. ��ʼѵ��
    try
        [net, ~] = trainNetwork(augimdsTrain, lgraph, options);
    catch ME
        fprintf('!!! Training failed for the current hyperparameter set: %s\n', ME.message);
        % ���ѵ��ʧ�� (��������ṹ��������Ϸ�)������һ���������Ӧ��ֵ
        fitness = inf; 
        net = []; % û����������
        return;
    end
    
    %% 8. ��ѵ���õ������� net ����֤������һ����������
    totalErr = 0;
    E = 10670;    % �� predictTrac �б���һ�µ��������
    
    for i=1:numVal
        dsplSample = val_dspl_array(:,:,:,i);
        tracGT     = val_trac_array(:,:,:,i);
        brdx       = [];
        brdy       = [];
        if ~isempty(val_brdx{i}), brdx = val_brdx{i}; end
        if ~isempty(val_brdy{i}), brdy = val_brdy{i}; end
    
        pred = predictTrac(net, dsplSample, E);
        % ���û���ṩ�߽磬����ֱ�� errorTrac(pred,tracGT)��
        % ����� brdx,brdy ����ȥ�� interior masking
        if isempty(brdx) || isempty(brdy)
            totalErr = totalErr + errorTrac_no_boundary(pred, tracGT);
        else
            totalErr = totalErr + errorTrac(pred, tracGT, brdx, brdy);
        end
    end
    
    meanErr = totalErr / numVal;
    fprintf('�� Fitness (Mean Relative Error): %.6f\n', meanErr);
    fitness = meanErr;
end

%% ����Ԥ��������㺯�� (������һ���ޱ߽�İ汾������³����)
function trac = predictTrac(net, dspl, E)
    S = size(dspl,1);
    mag = S/104;
    conversion = E/10*mag;
    trac = activations(net,dspl,'output')*conversion;
end

function errorT = errorTrac(trac,tracGT,brdx,brdy,varargin)
    % (����ԭʼ errorTrac �����������޸�)
    warning('off','all');
    if nargin==4
        cutoff = 0;
    elseif nargin==5
        cutoff = varargin{1};
    else
        disp('Error')
    end
    pgn = polyshape(brdx,brdy);
    [ydim,xdim,~] = size(trac);
    [X,Y] = meshgrid(1:xdim,1:ydim);
    interior = isinterior(pgn,Y(:),X(:));
    interior = reshape(interior,ydim,xdim);

    trac(:,:,1) = trac(:,:,1).*interior;
    trac(:,:,2) = trac(:,:,2).*interior;
    tracGT(:,:,1) = tracGT(:,:,1).*interior;
    tracGT(:,:,2) = tracGT(:,:,2).*interior;

    tracMag = sqrt(trac(:,:,1).^2+trac(:,:,2).^2);
    tracGTMag = sqrt(tracGT(:,:,1).^2+tracGT(:,:,2).^2);

    if cutoff>0
        threshold = prctile(tracGTMag(interior),cutoff);
        I = tracMag>threshold | tracGTMag>threshold;
        trac(:,:,1) = trac(:,:,1).*I;
        trac(:,:,2) = trac(:,:,2).*I;
        tracGT(:,:,1) = tracGT(:,:,1).*I;
        tracGT(:,:,2) = tracGT(:,:,2).*I;
    else
        I = ones(ydim,xdim);
    end

    mse = sum((trac(:,:,1)-tracGT(:,:,1)).^2 + (trac(:,:,2)-tracGT(:,:,2)).^2,'all')/nnz(interior.*I);
    rmse = sqrt(mse);
    msm = sum(tracGT(:,:,1).^2+tracGT(:,:,2).^2,'all')/nnz(interior.*I);
    rmsm = sqrt(msm);
    errorT = rmse/rmsm;
end

function errorT = errorTrac_no_boundary(trac, tracGT)
    % ���û���ṩ�߽磬��������ͼ������
    mse = mean((trac - tracGT).^2, 'all');
    rmse = sqrt(mse);
    msm = mean(tracGT.^2, 'all');
    rmsm = sqrt(msm);
    if rmsm == 0, errorT = inf; else, errorT = rmse / rmsm; end
end


% =========================================================================
% ======================= �µ��Ż������Ĵ��� ==============================
% =========================================================================

function [best_pos, Convergence_curve] = Enhanced_SBO(N, Max_FEs, lb, ub, dim, fobj)
    % (���ṩ�� Enhanced_SBO �㷨���룬�����޸�)
    
    %INITIALIZATION
    Convergence_curve = [];
    FEs = 0;
    
    current_X = initialization(N, dim, ub, lb);
    current_Fitness = inf * ones(N, 1);
    
    for i = 1:N
        current_Fitness(i, 1) = fobj(current_X(i, :));
        FEs = FEs + 1;
    end
    
    [bestFitness, best_idx] = min(current_Fitness);
    best_pos = current_X(best_idx, :);
    
    %% --- ENHANCEMENT 1: Reinforcement Learning (RL) Setup ---
    num_actions = 2; % Action 1: Exploration (DE), Action 2: Exploitation (SBO-like)
    Q_table = zeros(N, num_actions); % Q-table for each agent
    learning_rate = 0.5; % Alpha
    discount_factor = 0.9; % Gamma (not critical in this stateless version)
    epsilon = 0.5; % Initial exploration rate for action selection
    
    %% --- ENHANCEMENT 2: L-SHADE Parameter Adaptation Setup ---
    memory_size = N;
    M_F = 0.5 * ones(memory_size, 1); % Memory for scaling factor F
    M_CR = 0.5 * ones(memory_size, 1); % Memory for crossover rate CR
    mu_F = 0.5;
    mu_CR = 0.5;
    archive = []; % Archive for storing improved solutions
    archive_size_limit = 2 * N;
    k = 1; % Memory index
    
    %% --- ENHANCEMENT 3: Lens Opposition-Based Learning (OBL) Setup ---
    stagnation_counter = 0;
    stagnation_threshold = 30; % Trigger OBL after 30 iterations without improvement
    
	iter = 1;
    
    while FEs < Max_FEs
        
        S_F = []; % To store successful F values in this generation
        S_CR = []; % To store successful CR values in this generation
        
        % Update archive
        archive = [archive; current_X];
        if size(archive, 1) > archive_size_limit
            rand_indices = randperm(size(archive, 1));
            archive = archive(rand_indices(1:archive_size_limit), :);
        end
        
        for i = 1:N
            %% --- RL: Action Selection (Epsilon-Greedy) ---
            if rand < epsilon
                action = randi(num_actions); % Explore: choose a random action
            else
                [~, action] = max(Q_table(i, :)); % Exploit: choose the best-known action
            end
            
            %% --- L-SHADE: Generate Parameters F and CR ---
            % Generate CR
            cr_idx = randi(memory_size);
            CR = normrnd(M_CR(cr_idx), 0.1);
            CR = min(1, max(0, CR));
            
            % Generate F
            f_idx = randi(memory_size);
            F = -1;
            while F <= 0 % F must be positive
                F = cauchy_rnd(M_F(f_idx), 0.1);
            end
            F = min(1, F);
            
            %% Generate Trial Vector based on the selected action
            trial_X = zeros(1, dim);
            
            if action == 1 % Action 1: Exploration using 'DE/current-to-pbest/1'
                % Select pbest from top 10%
                p = 0.1;
                p_best_count = max(2, ceil(p*N));
                [~, sorted_indices] = sort(current_Fitness);
                pbest_idx = sorted_indices(randi(p_best_count));
                p_best_pos = current_X(pbest_idx, :);

                % Select r1 and r2
                r1_idx = randi(N); while r1_idx == i, r1_idx = randi(N); end
                r2_idx = randi(size(archive, 1)); while r2_idx == i, r2_idx = randi(size(archive, 1)); end
                
                v = current_X(i, :) + F * (p_best_pos - current_X(i, :)) + F * (current_X(r1_idx, :) - archive(r2_idx, :));

                % Binomial Crossover
                j_rand = randi(dim);
                for j = 1:dim
                    if rand < CR || j == j_rand
                        trial_X(j) = v(j);
                    else
                        trial_X(j) = current_X(i, j);
                    end
                end

            else % Action 2: Exploitation using an SBO-like operator
                Rolette_index = RouletteWheelSelection(1./current_Fitness);
                if Rolette_index == -1, Rolette_index = best_idx; end
                
                r1 = randn;
                r2 = randn;
                r3 = tanh((sqrt(abs(Max_FEs - randn * FEs))/iter)^(FEs/Max_FEs));
                
                for j = 1:dim
                    trial_X(j) = (1 - r1 - r2) * current_X(i, j) + r1 * current_X(Rolette_index, j) + r2 * best_pos(j);
                    if rand > r3
                        trial_X(j) = trial_X(j) * r3 * randn; % Add perturbation
                    end
                end
            end
            
            %% Boundary control
            trial_X = BoundaryControl(trial_X, lb, ub);
            
            %% Greedy Selection & Updates
            trial_Fitness = fobj(trial_X);
            FEs = FEs + 1;
            
            reward = 0;
            if trial_Fitness < current_Fitness(i)
                % Success
                current_X(i, :) = trial_X;
                current_Fitness(i) = trial_Fitness;
                reward = 1; % Positive reward for improvement
                
                % L-SHADE: Store successful parameters
                if action == 1
                    S_F(end+1) = F;
                    S_CR(end+1) = CR;
                end
                
                % Update global best if necessary
                if trial_Fitness < bestFitness
                    bestFitness = trial_Fitness;
                    best_pos = trial_X;
                    stagnation_counter = 0; % Reset stagnation counter on improvement
                end
            else
                % Failure
                reward = 0; % No reward for no improvement
                stagnation_counter = stagnation_counter + 1/N; % Increment stagnation counter
            end
            
            %% RL: Update Q-table
            % Simplified Q-learning update (since state is static per iteration)
            Q_table(i, action) = (1 - learning_rate) * Q_table(i, action) + learning_rate * reward;
        end
        
        %% --- L-SHADE: Update Parameter Memory ---
        if ~isempty(S_F)
            mu_F = (sum(S_F.^2) / sum(S_F)); % Lehmer mean for F
            M_F(k) = mu_F;
        end
        if ~isempty(S_CR)
            mu_CR = mean(S_CR); % Arithmetic mean for CR
            M_CR(k) = mu_CR;
        end
        k = k + 1;
        if k > memory_size, k = 1; end
        
        %% --- OBL: Trigger if stagnated ---
        if stagnation_counter >= stagnation_threshold
            % Generate lens-opposite solution
            k_obl = rand(); % Dynamic factor
            mid_point = (lb + ub) / 2;
            lens_opposite_pos = mid_point + k_obl * (mid_point - best_pos);
            
            lens_opposite_pos = BoundaryControl(lens_opposite_pos, lb, ub);
            
            lens_fitness = fobj(lens_opposite_pos);
            FEs = FEs + 1;
            
            if lens_fitness < bestFitness
                best_pos = lens_opposite_pos;
                bestFitness = lens_fitness;
                % Replace the worst individual with the OBL solution
                [~, worst_idx] = max(current_Fitness);
                current_X(worst_idx, :) = best_pos;
                current_Fitness(worst_idx) = bestFitness;
            end
            stagnation_counter = 0; % Reset counter after applying OBL
        end
        
        Convergence_curve(iter) = bestFitness;
        fprintf('Iteration: %d, FEs: %d/%d, Best Fitness: %.6f\n', iter, FEs, Max_FEs, bestFitness);
        iter = iter + 1;
        epsilon = epsilon * 0.99; % Decay epsilon over time
    end
end  

%% --- Helper Functions for Enhanced_SBO ---

function X = initialization(N, dim, ub, lb)
    Boundary_no = size(ub, 2); % Number of boundaries
    if Boundary_no == 1
        X = rand(N, dim) .* (ub - lb) + lb;
    else
        X = zeros(N, dim);
        for i = 1:N
            for j = 1:dim
                X(i, j) = rand .* (ub(j) - lb(j)) + lb(j);
            end
        end
    end
end

function X = BoundaryControl(X, low, up)
    [~, dim] = size(X);
    if numel(low) == 1 % Single boundary for all dimensions
        X(X < low) = low;
        X(X > up) = up;
    else % Boundary for each dimension
        for j=1:dim
            if X(j) < low(j), X(j) = low(j); end
            if X(j) > up(j), X(j) = up(j); end
        end
    end
end
    
function choice = RouletteWheelSelection(weights)
  weights(isinf(weights)) = 1e10; % Handle potential inf from 1/0
  weights(isnan(weights)) = 1e-10;
  if sum(weights) == 0
      choice = -1;
      return;
  end
  accumulation = cumsum(weights);
  if accumulation(end) == 0
      choice = -1;
      return;
  end
  p = rand() * accumulation(end);
  chosen_index = -1;
  for index = 1:length(accumulation)
    if (accumulation(index) > p)
      chosen_index = index;
      break;
    end
  end
  choice = chosen_index;
end  

function r = cauchy_rnd(mu, gamma)
    % Generates a random number from a Cauchy distribution
    r = mu + gamma * tan(pi * (rand - 0.5));
end
