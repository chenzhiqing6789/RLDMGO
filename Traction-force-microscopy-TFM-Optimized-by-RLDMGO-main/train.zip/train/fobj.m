% function fitness=fobj(trainingImages,trainingLabels,validImages,validLabels,cg,lb,ub)
function [fitness, net]=fobj(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,cg,lb,ub)
    %% 1. ��ʼ��
    cg = max(min(cg,ub), lb);
    %% 1. �� cg ��ȡ���������
    % 1.1 attention ���أ�bool��
    encoder_att = logical( cg(1:3) > 0.5 );   % 3 �� encoder attention
    decoder_att = logical( cg(4:7) > 0.5 );   % 4 �� decoder attention
    ef = round( cg(8:13) );                   % 6 ����
    encoder_filters = reshape(ef, 3, 2);    % �� [ [f11 f12]; [f21 f22]; [f31 f32] ]
    
    % 1.3 decoder_filters��4��2 ��������
    df = round( cg(14:21) );                  % 8 ����
    decoder_filters = reshape(df, 4, 2);    % �� [ [d11 d12]; ... ; [d41 d42] ]
   
    % 1.4 ѵ������
    ep                   = max(1, round(cg(22)));  % ���� epoch ��1
    lr                   = cg(23);                  % ��ʼѧϰ�ʣ����㣩
    LearnRateDropFactor  = cg(24);                  % ѧϰ���½�����
    L2Regularization     = cg(25);                  % L2 ����ǿ��
    LearnRateDropPeriod  = ceil(cg(26));  % ��ѧϰ�����ڣ����� ��1��
    solverNum   = ceil(cg(27)) ; 

    params.encoder_att        = encoder_att;          % �߼��� 1��3
    params.decoder_att        = decoder_att;          % �߼��� 1��4
    params.encoder_filters    = encoder_filters;      % ���� 3��2
    params.decoder_filters    = decoder_filters;      % ���� 4��2
    params.epochs             = ep;                   % ������
    params.learning_rate      = lr;                   % ������
    params.lr_drop_factor     = LearnRateDropFactor;  % ������
    params.l2_reg             = L2Regularization;     % ������
    params.lr_drop_period     = LearnRateDropPeriod;  % ����
    params.solver_number      = solverNum;            % ����
        % �������������� fprintf ���
    fprintf('\nѵ���������飺\n');
    fprintf('  encoder_att: [%s]\n', num2str(params.encoder_att));
    fprintf('  decoder_att: [%s]\n', num2str(params.decoder_att));
    fprintf('  encoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d]\n', params.encoder_filters');
    fprintf('  decoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d; %d %d]\n', params.decoder_filters');
    fprintf('  epochs: %d\n', params.epochs);
    fprintf('  learning rate: %.4g\n', params.learning_rate);
    fprintf('  lr drop factor: %.4g\n', params.lr_drop_factor);
    fprintf('  L2 regularization: %.4g\n', params.l2_reg);
    fprintf('  lr drop period: %d\n', params.lr_drop_period);
    fprintf('  solver number: %d\n', params.solver_number);
    %% 2. �����볬������
    S = 104;
%     encoder_att  = [true, true, true];
%     decoder_att  = [true, true, true, false];
%     encoder_filters = [32 64; 64 128; 128 256];
%     decoder_filters = [128 256; 64 128; 32 64; 1 32];
%      'ValidationData',      augimdsVal, ...
%             'ValidationFrequency', valFreq, ...
%     
    
%     ep = 2;           % ��� epoch
%     lr = 3e-3;        % ��ʼѧϰ��
   mag = S/104;
%     LearnRateDropFactor=0.7943;
%     L2Regularization=5e-4;
%     LearnRateDropPeriod=10;
%     solverNum   = 2;          % �û�ֻ����������ֵ
%     
    solverList  = {'sgdm','sgdm','sgdm'};
    
    solverType = solverList{solverNum};
    lgraph = createTracnet_optim2(S, encoder_att, decoder_att, ...
                                  encoder_filters, decoder_filters);

    
    %% 5. ���� minibatch ����֤Ƶ��
    numTrainFiles = numTrain;  
    MiniBatchSize      = ceil(20/mag);
    valFreq            = ceil(numTrainFiles/MiniBatchSize);


    switch lower(solverType)
       case 'sgdm'
           options = trainingOptions('sgdm', ...
                'InitialLearnRate',    lr, ...
                'LearnRateSchedule',   'piecewise', ...
                'LearnRateDropPeriod', LearnRateDropPeriod, ...
                'LearnRateDropFactor', LearnRateDropFactor, ...
                'L2Regularization',    L2Regularization, ...
                'MaxEpochs',           ep, ...
                'MiniBatchSize',       MiniBatchSize, ...
                'Shuffle',             'every-epoch', ...
                'GradientThreshold',   1, ...
                'VerboseFrequency',    2 ,...
                'Plots','training-progress');
    
      case 'adam'
          options = trainingOptions('adam', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'VerboseFrequency',    2);
    
      case 'rmsprop'
            options = trainingOptions('rmsprop', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'VerboseFrequency',    2);
    
    
      otherwise
        error('Unsupported solver type: %s', solverType);
    end
%     parpool(2); % ��������������

%     spmd
%         gpuIndex = spmdIndex; % ÿ�������߷��䲻ͬ��GPU
%         gpuDevice(gpuIndex); % ѡ��GPU
    
        % ���ݲ���ѵ��
     [net, info] = trainNetwork(augimdsTrain, lgraph, options);
%     end
    %% 7. ��ʼѵ��
%     [net, info] = trainNetwork(augimdsTrain, lgraph, options);
    
    %% 8. ��ѵ���õ������� net ����֤������һ����������
    totalErr = 0;
    E = 10670;    % �� predictTrac �б���һ�µ��������
    
    for i=1:numVal
        dsplSample = val_dspl_array(:,:,:,i);
        tracGT     = val_trac_array(:,:,:,i);
        brdx       = [];
        brdy       = [];
        if ~isempty(val_brdx{i}), brdx = val_brdx{i}; end
        if ~isempty(val_brdy{i}), brdy = val_brdy{i}; end
    
        pred = predictTrac(net, dsplSample, E);
        % ���û���ṩ�߽磬����ֱ�� errorTrac(pred,tracGT)��
        % ����� brdx,brdy ����ȥ�� interior masking
        totalErr = totalErr + errorTrac(pred, tracGT, brdx, brdy);
    end
    
    meanErr = totalErr / numVal;
    fprintf('�� ����ģ������֤���ϵ�ƽ������� %.4f\n', meanErr);
    fitness=meanErr;
    %% 9. ��������ģ��
    save('tracnet_final.mat','net','meanErr');
end
%% Ԥ�⺯�� (�޸ĺ�)
function trac = predictTrac(net, dspl, E)
    S = size(dspl,1);
    mag = S/104;
    conversion = E/10*mag;
    trac = activations(net,dspl,'output')*conversion;
end


function errorT = errorTrac(trac,tracGT,brdx,brdy,varargin)

%% define the region within the cell for calculating the error
warning('off','all');
if nargin==4
    cutoff = 0;
elseif nargin==5
    cutoff = varargin{1};
else
    disp('Error')
end
pgn = polyshape(brdx,brdy);
[ydim,xdim,~] = size(trac);
[X,Y] = meshgrid(1:xdim,1:ydim);
interior = isinterior(pgn,Y(:),X(:));
interior = reshape(interior,ydim,xdim);

trac(:,:,1) = trac(:,:,1).*interior;
trac(:,:,2) = trac(:,:,2).*interior;
tracGT(:,:,1) = tracGT(:,:,1).*interior;
tracGT(:,:,2) = tracGT(:,:,2).*interior;

tracMag = sqrt(trac(:,:,1).^2+trac(:,:,2).^2);
tracGTMag = sqrt(tracGT(:,:,1).^2+tracGT(:,:,2).^2);

if cutoff>0
    threshold = prctile(tracGTMag(interior),cutoff);
    I = tracMag>threshold | tracGTMag>threshold;
    trac(:,:,1) = trac(:,:,1).*I;
    trac(:,:,2) = trac(:,:,2).*I;
    tracGT(:,:,1) = tracGT(:,:,1).*I;
    tracGT(:,:,2) = tracGT(:,:,2).*I;
else
    I = ones(ydim,xdim);
end

mse = sum((trac(:,:,1)-tracGT(:,:,1)).^2 + (trac(:,:,2)-tracGT(:,:,2)).^2,'all')/nnz(interior.*I);
rmse = sqrt(mse);
msm = sum(tracGT(:,:,1).^2+tracGT(:,:,2).^2,'all')/nnz(interior.*I);
rmsm = sqrt(msm);
errorT = rmse/rmsm;

end


