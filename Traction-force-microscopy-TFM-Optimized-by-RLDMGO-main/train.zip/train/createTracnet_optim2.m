function lgraph = createTracnet_optim2(S, encoder_att, decoder_att, encoder_filters, decoder_filters)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% createTracnet(S, [encoder_att], [decoder_att])
% ��С�Ķ��汾������ע�������ؿ���
% encoder_att: [1��3 logical] ���������׶��Ƿ��ע���� (Ĭ��ȫtrue)
% decoder_att: [1��4 logical] ���������׶��Ƿ��ע���� (Ĭ��ȫtrue)

%% ���������Դ���������ԭ�е��÷�ʽ��
if nargin < 2, encoder_att = true(1,3); end
if nargin < 3, decoder_att = true(1,4); end

if nargin < 4 || isempty(encoder_filters)  % ����Ĭ�ϱ���������
    encoder_filters = [32 64; 64 128; 128 256]; 
end
if nargin < 5 || isempty(decoder_filters)  % ����Ĭ�Ͻ���������
    decoder_filters = [128 256; 64 128; 32 64; 1 32];
end

%% ԭʼ�������ñ��ֲ���
inputSize = [S S 2];
inputLayer = image3dInputLayer(inputSize,'Normalization','none','Name','input');
numFiltersEncoder = encoder_filters;
layers = [inputLayer];

%% �Ľ���1��������ģ������������
encoder_outputs = cell(3,1); % ��¼������������ڵ�
decoder_outputs = cell(4,1);
for module = 1:3
    layer_name = num2str(module);
    encoderModule = [
        convolution3dLayer([3 3 2], numFiltersEncoder(module,1), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['en', layer_name, '_conv1']);
        batchNormalizationLayer('Name', ['en', layer_name, '_bn']);
        reluLayer('Name', ['en', layer_name, '_relu1']);
        convolution3dLayer([3 3 2], numFiltersEncoder(module,2), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['en', layer_name, '_conv2']);
        reluLayer('Name', ['en', layer_name, '_relu2'])
    ];

    %%% ��������ע����ģ�� %%%
    if encoder_att(module)
        encoderModule = [encoderModule;
            globalAveragePooling3dLayer('Name', ['en', layer_name, '_gap']);
            fullyConnectedLayer(numFiltersEncoder(module,2), 'Name', ['en', layer_name, '_fc1']);
            reluLayer('Name', ['en', layer_name, '_relu3']);
            fullyConnectedLayer(numFiltersEncoder(module,2), 'Name', ['en', layer_name, '_fc2']);
            sigmoidLayer('Name', ['en', layer_name, '_sigmoid1']);
            multiplicationLayer(2, 'Name', ['en', layer_name, '_channel_mult']);
            
            convolution3dLayer([3 3 3], 1, 'Padding', 'same', 'Name', ['en', layer_name, '_spatial_conv']);
            sigmoidLayer('Name', ['en', layer_name, '_sigmoid2']);
            multiplicationLayer(2, 'Name', ['en', layer_name, '_spatial_mult'])
        ];
        encoder_outputs{module} = "en" + layer_name + "_spatial_mult"; % �ַ�������
    else
         encoder_outputs{module} = "en" + layer_name + "_relu2"; 
    end

    encoderModule = [encoderModule;
        maxPooling3dLayer([2,2,1], 'Stride', [2,2,1], 'Padding', 'same', ...
            'Name', ['en', layer_name, '_maxpool'])
    ];
    layers = [layers; encoderModule];
end

%% �Ľ���2��������ģ������������
numFiltersDecoder = decoder_filters;
for module = 1:4
    layer_name = num2str(-module+5);
    decodeModule = [
        convolution3dLayer([3 3 2], numFiltersDecoder(module,1), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['de', layer_name, '_conv1']);
        batchNormalizationLayer('Name', ['de', layer_name, '_bn1']);
        reluLayer('Name', ['de', layer_name, '_relu1']);
        convolution3dLayer([3 3 2], numFiltersDecoder(module,2), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['de', layer_name, '_conv2']);
        batchNormalizationLayer('Name', ['de', layer_name, '_bn2']);        
        reluLayer('Name', ['de', layer_name, '_relu2'])
    ];


    %%% �޸��㣺���н���������ǰ׺��Ϊde %%%
    if decoder_att(module)
        decodeModule = [decodeModule;
            globalAveragePooling3dLayer('Name', ['de', layer_name, '_gap']);
            fullyConnectedLayer(numFiltersDecoder(module,2), 'Name', ['de', layer_name, '_fc1']);
            reluLayer('Name', ['de', layer_name, '_relu3']);
            fullyConnectedLayer(numFiltersDecoder(module,2), 'Name', ['de', layer_name, '_fc2']);
            sigmoidLayer('Name', ['de', layer_name, '_sigmoid1']);
            multiplicationLayer(2, 'Name', ['de', layer_name, '_channel_mult']);
            
            convolution3dLayer([3 3 3], 1, 'Padding', 'same', 'Name', ['de', layer_name, '_spatial_conv']);
            sigmoidLayer('Name', ['de', layer_name, '_sigmoid2']);
            multiplicationLayer(2, 'Name', ['de', layer_name, '_spatial_mult'])
        ];
        decoder_outputs{module} = "de" + layer_name + "_spatial_mult"; % �ؼ��޸���
    else
        decoder_outputs{module} = "de" + layer_name + "_relu2"; 
    end

    decodeModule = [decodeModule;
        transposedConv3dLayer([3,3,1], numFiltersDecoder(module,2), 'Stride', [2,2,1], 'Cropping', 'same', ...
            'WeightsInitializer', 'narrow-normal', 'BiasInitializer', 'zeros', ...
            'Name', ['de', layer_name, '_transconv'])
    ];
    
    layers = [layers; decodeModule];
end


%create output layers
% lgraph = layerGraph(layers);
% lgraph = removeLayers(lgraph, 'de1_transconv');
% layer =  convolution3dLayer([3 3 2], 1, ...
%             'Padding','same','WeightsInitializer','narrow-normal', ...
%             'BiasInitializer', 'zeros', ...
%             'Name',['de1_conv3']);
% lgraph = addLayers(lgraph,layer);
% lgraph = connectLayers(lgraph,'de1_relu2','de1_conv3');
% layer = regressionLayer('name','output');
% lgraph = addLayers(lgraph,layer);
% lgraph = connectLayers(lgraph, 'de1_conv3','output');



%% ����ԭʼ�����ṹ����
% layers = [layers;
%     convolution3dLayer([3 3 2], 1, ...
%         'Padding','same','WeightsInitializer','narrow-normal', ...
%         'BiasInitializer', 'zeros', 'Name','de1_conv3');
%     regressionLayer('name','output')];
% 
lgraph = layerGraph(layers);

lgraph = removeLayers(lgraph, 'de1_transconv');
layer =  convolution3dLayer([3 3 2], 1, ...
            'Padding','same','WeightsInitializer','narrow-normal', ...
            'BiasInitializer', 'zeros', ...
            'Name',['de1_conv3']);
lgraph = addLayers(lgraph,layer);
if decoder_att(4)
   lgraph = connectLayers(lgraph,'de1_spatial_mult','de1_conv3');
else
   lgraph = connectLayers(lgraph,'de1_relu2','de1_conv3');
end
layer = regressionLayer('name','output');
lgraph = addLayers(lgraph,layer);
lgraph = connectLayers(lgraph, 'de1_conv3','output');
for module = 1:3
    
    
     if encoder_att(module)
          layer_name = num2str(module);
          lgraph = connectLayers(lgraph, ['en', layer_name, '_relu2'], ['en', layer_name, '_channel_mult/in2']); 
          lgraph = connectLayers(lgraph, ['en', layer_name, '_channel_mult'], ['en', layer_name, '_spatial_mult/in2']);
     end
  
end

%% �Ľ���4��������ע�����������������޸��棩
for module = 1:4
    layer_name = num2str(-module+5);
    
    % �������ø�ģ���ע����ʱ��ִ������
    if decoder_att(module)
        % 遍历�?有编码器和解码器模块
        %% ͨ��ע��������
        channel_src = ['de', layer_name, '_relu2'];
        channel_dest = ['de', layer_name, '_channel_mult/in2'];
        if ~hasConnection(lgraph, channel_src, channel_dest)
            lgraph = connectLayers(lgraph, channel_src, channel_dest);
        end
        
        %% �ռ�ע��������
        spatial_src = ['de', layer_name, '_channel_mult'];
        spatial_dest = ['de', layer_name, '_spatial_mult/in2'];
        if ~hasConnection(lgraph, spatial_src, spatial_dest)
            lgraph = connectLayers(lgraph, spatial_src, spatial_dest);
        end
    end
end

%% �������������������ļ�ĩβ��
function existFlag = hasConnection(lgraph, src, dest)
% ���ָ�������Ƿ��Ѵ���
   existFlag = any(strcmp(lgraph.Connections.Source, src) & ...
                strcmp(lgraph.Connections.Destination, dest));
end


concat_config = [ % ��Ϊ��ά�ַ�������
    "en1", "concat1/in1", "de2_transconv"; 
    "en2", "concat2/in1", "de3_transconv"; 
    "en3", "concat3/in1", "de4_transconv"
];

for i = 1:3
    % ֱ�Ӱ�����������
    concat_name = concat_config(i,1);
    in_port = concat_config(i,2);
    deconv_layer = concat_config(i,3);
    
    % ͳһʹ���ַ���ƴ��
    lgraph = disconnectLayers(lgraph, deconv_layer, "de" + i + "_conv1");
    concat_layer = concatenationLayer(4,2,'Name',char(concat_name)); % ת��Ϊchar
    lgraph = addLayers(lgraph, concat_layer);
    lgraph = connectLayers(lgraph, encoder_outputs{i}, concat_name + "/in1");
    lgraph = connectLayers(lgraph, deconv_layer, concat_name + "/in2");
    lgraph = connectLayers(lgraph, concat_name + "/out", "de" + i + "_conv1");
end

%% ����ԭʼ���������߼�
analyzeNetwork(lgraph);
fn = sprintf('tracnetGraph%d_AttEnc%d%d%d_Dec%d%d%d%d.mat',S,...
    encoder_att(1),encoder_att(2),encoder_att(3),...
    decoder_att(1),decoder_att(2),decoder_att(3),decoder_att(4));
save(fn,'lgraph');
end
