%% 1. ׼�����������峬������Χ
% ����һ������ĳ������� cg(1��27)������ֻ��ʾ����ʵ�����Ż�������
% lb = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  5, 1e-4,0.5, 3e-3, 10, 0.1];
% ub = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 5, 3e-3,0.9, 1e-3,  20,   3];
% 
% 
% 
% lb = [1, 0, 1, 1, 1, 1,	0, 8,  34, 64, 116, 101,256,110, 255, 40, 120, 19,44,2,	26,	158, 0.00234586, 0.884538233, 0.000530496, 14, 2.1]
% 
% 
% lb2 = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  15, 1e-4,0.5, 3e-3, 10, 0.1];
% ub2 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 15, 3e-3,0.9, 1e-3,  20,   3];
% 
% lb3 = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  30, 1e-4,0.5, 3e-3, 10, 0.1];
% ub3 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 30, 3e-3,0.9, 1e-3,  20,   3];



% lb = [0, 0, 0, 0, 0, 0,	0, 7,  32, 64, 116, 101,256, 110, 255, 40, 120, 19,44, 2, 26, 5, 0.00234586, 0.884538233, 0.000530496, 14, 2.1];
% ub = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128, 128,256, 128, 256, 64, 128, 32,64, 2, 32, 5,   3e-3,       0.9,       1e-3,        20,   3];

lb = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  1, 1e-4,0.5, 1e-3, 10, 0.1];
ub = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 1, 3e-3,0.9, 3e-3, 20,   3];


% lb2 = [0, 0, 0, 0, 0, 0, 0, 7,  32, 64, 116, 101,256, 110, 255, 40, 120, 19,44, 2, 26, 10, 0.00234586, 0.884538233, 0.000530496, 14, 2.1];
% ub2 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128, 128,256, 128, 256, 64, 128, 32,64, 2, 32, 10,   3e-3,       0.9,         1e-3,      20,   3];


lb2 = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  1, 1e-4,0.5, 1e-3, 10, 0.1];
ub2 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 1, 3e-3,0.9, 3e-3, 20,   3];


% lb3 = [0, 0, 0, 0, 0, 0, 0, 7,  32, 64, 116, 101,256, 110, 255, 40, 120, 19,44, 2, 26, 50,  0.00234586, 0.884538233, 0.000530496, 14, 2.1];
% ub3 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128, 128,256, 128, 256, 64, 128, 32,64, 2, 32, 50,   3e-3,       0.9,         1e-3,       20,  3];
lb3 = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  1, 1e-4,0.5, 1e-3, 10, 0.1];
ub3 = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 1, 3e-3,0.9, 3e-3, 20,   3];


S=104;

%% 2. ����ѵ���� augmentedImageDatastore
% --- ע�⣺����������� .mat �ļ���ı������� dspl �� trac
fn_dspl    = sprintf('trainData%d/dspl',S);
fn_dsplR   = sprintf('trainData%d/dsplRadial',S);
fn_trac    = sprintf('trainData%d/trac',S);
fn_tracR   = sprintf('trainData%d/tracRadial',S);
    
dsplDS = imageDatastore({fn_dspl,fn_dsplR},  'FileExtensions','.mat','ReadFcn',@load);
tracDS = imageDatastore({fn_trac,fn_tracR},  'FileExtensions','.mat','ReadFcn',@load);
    
 % Ԥ���䲢����
 numTrain = numel(dsplDS.Files);
% numTrain = 6;
dspl_array = zeros(S,S,2,numTrain,'single');
trac_array = zeros(S,S,2,numTrain,'single');
for i=1:numTrain
    tmp1 = load(dsplDS.Files{i}); dspl_array(:,:,:,i) = tmp1.dspl;
    tmp2 = load(tracDS.Files{i}); trac_array(:,:,:,i) = tmp2.trac;
end
    
augimdsTrain = augmentedImageDatastore([S S 2], dspl_array, trac_array);

%% 3. ������֤�� augmentedImageDatastore
val_dspl_path = 'C:/Users/11066/Desktop/DL-TFM-main1/DL-TFM-main1/test/generic/testData104/dspl/';

 
val_trac_path = 'C:/Users/11066/Desktop/DL-TFM-main1/DL-TFM-main1/test/generic/testData104/trac/';
val_dspl_files = dir(fullfile(val_dspl_path,'MLData*.mat'));
val_trac_files = dir(fullfile(val_trac_path,'MLData*.mat'));
numVal = numel(val_dspl_files);
    
val_dspl_array = zeros(S,S,2,numVal,'single');
val_trac_array = zeros(S,S,2,numVal,'single');
% �������Ҫ�߽����Σ���һ��������
val_brdx = cell(numVal,1);
val_brdy = cell(numVal,1);
    
for i=1:numVal
    tmp1 = load(fullfile(val_dspl_path,  val_dspl_files(i).name));
    tmp2 = load(fullfile(val_trac_path,  val_trac_files(i).name));
    val_dspl_array(:,:,:,i) = tmp1.dspl;
    val_trac_array(:,:,:,i) = tmp2.trac;
    if isfield(tmp2,'brdx'), val_brdx{i} = tmp2.brdx; end
    if isfield(tmp2,'brdy'), val_brdy{i} = tmp2.brdy; end
end
    
augimdsVal = augmentedImageDatastore([S S 2], val_dspl_array, val_trac_array);

if ~hasdata(augimdsVal)
    error('��֤���ݼ�Ϊ�գ��������ݼ���·��');
end


%% 3. RLSBO ������ (�����ֶ�����ÿ�׶εĲ���)
optimizer_option = struct();
optimizer_option.dim             = numel(lb);
optimizer_option.lb              = lb;
optimizer_option.ub              = ub;
optimizer_option.lb2             = lb2;
optimizer_option.ub2             = ub2;
optimizer_option.lb3             = lb3;
optimizer_option.ub3             = ub3;

%% 5. ���� Enhanced_SBO_CNN
%% 4. ���÷ּ��Ż��� RLSBO_CNN_Staged
[BestLocation, CNVG, bestNet, final_X3, final_Fitness3] = MGO_CNN_Staged( ...
    augimdsTrain, numTrain, ...
    augimdsVal,   numVal, ...
    val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
    optimizer_option ...
);

%% 5. ������
save('bestTracNet_Stagedfinal.mat','bestNet');
save('RLSBO_CNN_Staged_Result.mat','BestLocation','CNVG');
writematrix(BestLocation,'BestLocation_Staged.csv');
writematrix(CNVG',       'CNVG_Staged.csv'); % ת��һ�·���鿴

% --- �������룺��������Ҫ�󱣴� final_X3 �� final_Fitness3 ---
writematrix(final_X3,       'final_X3_Staged.csv');
writematrix(final_Fitness3, 'final_Fitness3_Staged.csv');

% =========================================================================
% ================ �µķּ��Ż������� RLSBO_CNN_Staged ====================
% =========================================================================

function [BestLocation, Overall_CNVG, bestNet3,final_X3, final_Fitness3] = MGO_CNN_Staged(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,optimizer_option)
    %% 1. ��ʼ��
    disp('Staged Enhanced SBO is now tackling your problem');
    tic;

    dim = optimizer_option.dim;
    lb  = optimizer_option.lb; 
    ub  = optimizer_option.ub;

    lb2  = optimizer_option.lb2; 
    ub2  = optimizer_option.ub2;

    lb3  = optimizer_option.lb3; 
    ub3  = optimizer_option.ub3;

    %% 2. ����Ŀ�꺯���İ�װ�� (Wrapper)
    fobj_wrapped = @(x) fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                              val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                              x, lb, ub);
    
    fobj_wrapped2 = @(x) fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                              val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                              x, lb2, ub2);
    fobj_wrapped3 = @(x) fobj1(augimdsTrain, numTrain, augimdsVal, numVal, ...
                              val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
                              x, lb3, ub3);

     
    %% ======================= STAGE 1 =======================
    disp('--- Starting Stage 1: Broad Search ---');
    N1 = 5;
    Max_FEs1 = 5;
    fprintf('Population: %d, FEs: %d\n', N1, Max_FEs1);
    
    [best_pos1, CNVG1, final_X1, final_Fitness1,~] = MGO(N1, Max_FEs1, lb, ub, dim, fobj_wrapped);
    
    GlobalBestLocation = best_pos1;
    GlobalBestFitness = CNVG1(end);
    Overall_CNVG = CNVG1;

    %% ======================= STAGE 2 =======================
    disp('--- Starting Stage 2: Focused Search ---');
    N2 = 5;
    Max_FEs2 = 5;
    fprintf('Population: %d (Top %d from Stage 1), FEs: %d\n', N2, N2, Max_FEs2);

    % ɸѡ��ǰ10���ľ�Ӣ
    [~, sorted_indices] = sort(final_Fitness1);
    elite_indices = sorted_indices(1:N2);
    initial_X2 = final_X1(elite_indices, :);
    initial_Fitness2 = final_Fitness1(elite_indices);

    [best_pos2, CNVG2, final_X2, final_Fitness2,~] = MGO(N2, Max_FEs2, lb2, ub2, dim, fobj_wrapped2, initial_X2, initial_Fitness2);
    
    % ����ȫ�����Ž�
    if CNVG2(end) < GlobalBestFitness
        GlobalBestLocation = best_pos2;
        GlobalBestFitness = CNVG2(end);
    end
    Overall_CNVG = [Overall_CNVG, CNVG2];

    %% ======================= STAGE 3 =======================
    disp('--- Starting Stage 3: Elite Refinement ---');
    N3 = 5;
    Max_FEs3 = 5;
    fprintf('Population: %d (Top %d from Stage 2), FEs: %d\n', N3, N3, Max_FEs3);

    % ɸѡ��ǰ5���ľ�Ӣ
    [~, sorted_indices] = sort(final_Fitness2);
    elite_indices = sorted_indices(1:N3);
    initial_X3 = final_X2(elite_indices, :);
    initial_Fitness3 = final_Fitness2(elite_indices);

    [best_pos3, CNVG3, final_X3, final_Fitness3,bestNet3] = MGO(N3, Max_FEs3, lb3, ub3, dim, fobj_wrapped3, initial_X3, initial_Fitness3);

    % ����ȫ�����Ž�
    if CNVG3(end) < GlobalBestFitness
        GlobalBestLocation = best_pos3;
        GlobalBestFitness = CNVG3(end);
    end
    Overall_CNVG = [Overall_CNVG, CNVG3];
    
    BestLocation = GlobalBestLocation; % ���յ����λ��


    toc;
end


%% --- Helper Functions ---
function [best_M, Convergence_curve, current_X, current_Fitness,bestnet] = MGO(N, Max_FEs, lb, ub, dim, fobjj, initial_X, initial_Fitness)

    bestnet = []; 
    Convergence_curve = [];
    FEs = 0;
    best_cost=inf;
    
    % --- MODIFICATION: Conditional Initialization ---
    if nargin < 7 || isempty(initial_X)
        % Standard start: Randomly initialize and evaluate the population
        current_X = initialization(N, dim, ub, lb);
        current_Fitness = inf * ones(N, 1);
        for i = 1:N
            if FEs >= Max_FEs, break; end
            [current_Fitness(i, 1),net] = fobjj(current_X(i, :));
            FEs = FEs + 1;

            if current_Fitness(i,1) < best_cost
                best_cost = current_Fitness(i,1);
                bestnet = net; % ���µ�ǰ��õ�����
                save('bestTracNet_Staged.mat','bestnet');
            end
        end
    else
        % Staged start: Use the provided elite population
        current_X = initial_X;
        current_Fitness = initial_Fitness;

        [best_cost, best_idx] = min(current_Fitness);
        best_M = current_X(best_idx, :);
        Convergence_curve = best_cost;
        if isempty(bestnet)
            [~, bestnet] = fobjj(best_M);
            save('bestTracNet_Staged.mat','bestnet');
        end
        


        % FEs counter for this stage starts at 0
    end

    if FEs >= Max_FEs % Handle cases where initialization exceeds FEs
        [best_cost, best_idx] = min(current_Fitness);
        best_M = current_X(best_idx, :);
        Convergence_curve = best_cost;
        if isempty(bestnet)
            [~, bestnet] = fobjj(best_M);
            save('bestTracNet_Staged.mat','bestnet');
        end
        return;
    end
    
    [best_cost, best_idx] = min(current_Fitness);
    best_M = current_X(best_idx, :);

it=1;
rec = 1;

w = 2;
rec_num = 10;
divide_num = dim/4;
% divide_num = min(SearchAgents_no/4, dim/4);
d1 = 0.2;

newM = zeros(SearchAgents_no, dim);
newM_cost = zeros(1, SearchAgents_no);
rM = zeros(SearchAgents_no,dim,rec_num); %record history positions
rM_cos = zeros(1,SearchAgents_no,rec_num);
%% Main Loop
while FEs<MaxFEs
    calPositions = M;
    div_num = randperm(dim);
        %Divide the population and select the regions with more individuals based on the best
        for j=1:max(divide_num,1)
            th = best_M(div_num(j));
            index = calPositions(:,div_num(j)) > th;
            if sum(index) < size(calPositions, 1)/2 %choose the side of the majority
                index = ~index;
            end
            calPositions = calPositions(index,:);%��0�ľͲ�������
        end
    D = best_M - calPositions; %Compute the distance from individuals to the best
    D_wind = sum(D, 1)/size(calPositions, 1); %Calculate the mean of all distances
 
    beta = size(calPositions, 1) / SearchAgents_no;
    gama = 1/sqrt(1-power(beta,2));
    step = w * (rand(size(D_wind))-0.5) * (1-FEs/MaxFEs);
    step2 = 0.1*w*(rand(size(D_wind))-0.5)* (1-FEs/MaxFEs)*(1+1/2*(1+tanh(beta/gama))*(1-FEs/MaxFEs));
    step3 = 0.1*(rand()-0.5) * (1-FEs/MaxFEs);
    act =actCal(1 ./ 1 + (0.5 - 10*(rand(size(D_wind)))));
    
    if rec == 1 %record the first generation of positions
        rM(:,:,rec) = M;
        rM_cos(1,:,rec) = costs;
        rec = rec + 1;
    end
  
    for i=1:SearchAgents_no    
        newM(i,:) = M(i,:);
        %Spore dispersal search
        %Update M using Eq.(6)
         if rand()>d1
            newM(i,:) = newM(i,:) + step .* D_wind; 
         else
            newM(i,:) = newM(i,:) + step2 .* D_wind;
        end

        if rand() < 0.8
            % Dual propagation search
            %Update M using Eq.(11)
            if rand() > 0.5
                newM(i,div_num(1)) = best_M(div_num(1)) + step3 * D_wind(div_num(1));
            else
                newM(i,:) = (1-act) .* newM(i,:)+act .* best_M;
            end
        end
              
        %Boundary absorption
        Flag4ub=newM(i,:)>ub;
        Flag4lb=newM(i,:)<lb;
        newM(i,:)=(newM(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
 
%         newM_cost(i)=fobj(newM(i,:));
        [newM_cost(i),net] = fobjj(newM(i,:));
        FEs=FEs+1;
        
        % Cryptobiosis mechanism
        rM(i,:,rec) = newM(i,:);
        rM_cos(1,i,rec) = newM_cost(i);
        
        
        if newM_cost(i)<best_cost 
           best_M=newM(i,:);
           best_cost=newM_cost(i);

%            bestFitness = trial_Fitness;
%            best_pos = trial_X;
           bestnet=net;
           save('bestTracNet_Staged.mat','bestnet')
        end    
    end %End for
    
    rec = rec + 1;
    % Cryptobiosis mechanism
    if rec > rec_num || FEs>=MaxFEs
        [lcost,Iindex] = min(rM_cos, [] ,3);
        for i=1:SearchAgents_no
            M(i,:) = rM(i,:,Iindex(i));
        end
        costs = lcost;
        rec = 1;
    end
    
    Convergence_curve(it)=best_cost;
    it=it+1;
end
end

function [act] = actCal(X)
    act = X;
    act(act>=0.5) = 1;
    act(act<0.5) = 0;
end


% This function initialize the first population of search agents
function X=initialization(nP,dim,ub,lb)

    Boundary_no= size(ub,2); % numnber of boundaries

    % If the boundaries of all variables are equal and user enter a signle
    % number for both ub and lb
    if Boundary_no==1
        X=rand(nP,dim).*(ub-lb)+lb;
    end

    % If each variable has a different lb and ub
    if Boundary_no>1
        for i=1:dim
            ub_i=ub(i);
            lb_i=lb(i);
            X(:,i)=rand(nP,1).*(ub_i-lb_i)+lb_i;
        end
    end
end
    
function r = cauchy_rnd(mu, gamma)
    % Generates a random number from a Cauchy distribution
    r = mu + gamma * tan(pi * (rand - 0.5));
end



%% --- Helper Functions ---


function X = BoundaryControl(X, low, up)
    if numel(low) == 1 % Single boundary for all dimensions
        X(X < low) = low;
        X(X > up) = up;
    else % Boundary for each dimension
        X = max(X, low);
        X = min(X, up);
    end
end





% =========================================================================
% ============ Ŀ�꺯�� fobj1 (�����κ��޸�) ============================
% =========================================================================

function [fitness, net]=fobj1(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,cg,lb,ub)
    %% 1. ��ʼ��
    cg = max(min(cg,ub), lb);
    %% 1. �� cg ��ȡ���������
    % 1.1 attention ���أ�bool��
    encoder_att = logical( cg(1:3) > 0.5 );   % 3 �� encoder attention
    decoder_att = logical( cg(4:7) > 0.5 );   % 4 �� decoder attention
    ef = round( cg(8:13) );                   % 6 ����
    encoder_filters = reshape(ef, 3, 2);    % �� [ [f11 f12]; [f21 f22]; [f31 f32] ]
    
    % 1.3 decoder_filters��4��2 ��������
    df = round( cg(14:21) );                  % 8 ����
    decoder_filters = reshape(df, 4, 2);    % �� [ [d11 d12]; ... ; [d41 d42] ]
   
    % 1.4 ѵ������
    ep                   = max(1, round(cg(22)));  % ���� epoch ��1
    lr                   = cg(23);                  % ��ʼѧϰ�ʣ����㣩
    LearnRateDropFactor  = cg(24);                  % ѧϰ���½�����
    L2Regularization     = cg(25);                  % L2 ����ǿ��
    LearnRateDropPeriod  = ceil(cg(26));  % ��ѧϰ�����ڣ����� ��1��
    solverNum   = ceil(cg(27)) ; 

    params.encoder_att        = encoder_att;          % �߼��� 1��3
    params.decoder_att        = decoder_att;          % �߼��� 1��4
    params.encoder_filters    = encoder_filters;      % ���� 3��2
    params.decoder_filters    = decoder_filters;      % ���� 4��2
    params.epochs             = ep;                   % ������
    params.learning_rate      = lr;                   % ������
    params.lr_drop_factor     = LearnRateDropFactor;  % ������
    params.l2_reg             = L2Regularization;     % ������
    params.lr_drop_period     = LearnRateDropPeriod;  % ����
    params.solver_number      = solverNum;            % ����
        % �������������� fprintf ���
    fprintf('\n--- Evaluating New Hyperparameters ---\n');
    fprintf('  encoder_att: [%s]\n', num2str(params.encoder_att));
    fprintf('  decoder_att: [%s]\n', num2str(params.decoder_att));
    fprintf('  encoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d]\n', params.encoder_filters');
    fprintf('  decoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d; %d %d]\n', params.decoder_filters');
    fprintf('  epochs: %d\n', params.epochs);
    fprintf('  learning rate: %.4g\n', params.learning_rate);
    fprintf('  lr drop factor: %.4g\n', params.lr_drop_factor);
    fprintf('  L2 regularization: %.4g\n', params.l2_reg);
    fprintf('  lr drop period: %d\n', params.lr_drop_period);
    fprintf('  solver number: %d\n', params.solver_number);
    %% 2. �����볬������
    S = 104;
    solverList  = {'sgdm','sgdm','sgdm'}; % Note: Original code has 3 'sgdm'. Should be {'sgdm', 'adam', 'rmsprop'}?
    solverType = solverList{solverNum};
    
    % ��̬���������ͼ (���� createTracnet_optim2 ����������·����)
    lgraph = createTracnet_optim2(S, encoder_att, decoder_att, ...
                                  encoder_filters, decoder_filters);
    
    %% 5. ���� minibatch ����֤Ƶ��
    numTrainFiles = numTrain;  
    mag = S/104;
    MiniBatchSize      = ceil(40/mag);
    valFreq            = ceil(numTrainFiles/MiniBatchSize);

    % ���� solverType ѡ��ѵ��ѡ��
    switch lower(solverType)
       case 'sgdm'
          options = trainingOptions('sgdm', ...
                'InitialLearnRate',    lr, ...
                'LearnRateSchedule',   'piecewise', ...
                'LearnRateDropPeriod', LearnRateDropPeriod, ...
                'LearnRateDropFactor', LearnRateDropFactor, ...
                'L2Regularization',    L2Regularization, ...
                'MaxEpochs',           ep, ...
                'MiniBatchSize',       MiniBatchSize, ...
                'Shuffle',             'every-epoch', ...
                'GradientThreshold',   1, ...
                'Verbose',             1, ... % ���ı����
                'Plots',               'training-progress'); % ��ѵ������ͼ

    
      case 'adam'
          options = trainingOptions('adam', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'Verbose',             0, ...
            'Plots',               'none');
    
      case 'rmsprop'
            options = trainingOptions('rmsprop', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'Verbose',             0, ...
            'Plots',               'none');
    
      otherwise
        error('Unsupported solver type: %s', solverType);
    end
    
    %% 7. ��ʼѵ��
    try
        [net, ~] = trainNetwork(augimdsTrain, lgraph, options);
    catch ME
        fprintf('!!! Training failed for the current hyperparameter set: %s\n', ME.message);
        % ���ѵ��ʧ�� (��������ṹ��������Ϸ�)������һ���������Ӧ��ֵ
        fitness = inf; 
        net = []; % û����������
        return;
    end
    
    %% 8. ��ѵ���õ������� net ����֤������һ����������
    totalErr = 0;
    E = 10670;    % �� predictTrac �б���һ�µ��������
    
    for i=1:numVal
        dsplSample = val_dspl_array(:,:,:,i);
        tracGT     = val_trac_array(:,:,:,i);
        brdx       = [];
        brdy       = [];
        if ~isempty(val_brdx{i}), brdx = val_brdx{i}; end
        if ~isempty(val_brdy{i}), brdy = val_brdy{i}; end
    
        pred = predictTrac(net, dsplSample, E);
        % ���û���ṩ�߽磬����ֱ�� errorTrac(pred,tracGT)��
        % ����� brdx,brdy ����ȥ�� interior masking
        if isempty(brdx) || isempty(brdy)
            totalErr = totalErr + errorTrac_no_boundary(pred, tracGT);
        else
            totalErr = totalErr + errorTrac(pred, tracGT, brdx, brdy);
        end
    end
    
    meanErr = totalErr / numVal;
    fprintf('�� Fitness (Mean Relative Error): %.6f\n', meanErr);
    fitness = meanErr;
end

%% ����Ԥ��������㺯�� (������һ���ޱ߽�İ汾������³����)
function trac = predictTrac(net, dspl, E)
    S = size(dspl,1);
    mag = S/104;
    conversion = E/10*mag;
    trac = activations(net,dspl,'output')*conversion;
end

function errorT = errorTrac(trac,tracGT,brdx,brdy,varargin)
    % (����ԭʼ errorTrac �����������޸�)
    warning('off','all');
    if nargin==4
        cutoff = 0;
    elseif nargin==5
        cutoff = varargin{1};
    else
        disp('Error')
    end
    pgn = polyshape(brdx,brdy);
    [ydim,xdim,~] = size(trac);
    [X,Y] = meshgrid(1:xdim,1:ydim);
    interior = isinterior(pgn,Y(:),X(:));
    interior = reshape(interior,ydim,xdim);

    trac(:,:,1) = trac(:,:,1).*interior;
    trac(:,:,2) = trac(:,:,2).*interior;
    tracGT(:,:,1) = tracGT(:,:,1).*interior;
    tracGT(:,:,2) = tracGT(:,:,2).*interior;

    tracMag = sqrt(trac(:,:,1).^2+trac(:,:,2).^2);
    tracGTMag = sqrt(tracGT(:,:,1).^2+tracGT(:,:,2).^2);

    if cutoff>0
        threshold = prctile(tracGTMag(interior),cutoff);
        I = tracMag>threshold | tracGTMag>threshold;
        trac(:,:,1) = trac(:,:,1).*I;
        trac(:,:,2) = trac(:,:,2).*I;
        tracGT(:,:,1) = tracGT(:,:,1).*I;
        tracGT(:,:,2) = tracGT(:,:,2).*I;
    else
        I = ones(ydim,xdim);
    end

    mse = sum((trac(:,:,1)-tracGT(:,:,1)).^2 + (trac(:,:,2)-tracGT(:,:,2)).^2,'all')/nnz(interior.*I);
    rmse = sqrt(mse);
    msm = sum(tracGT(:,:,1).^2+tracGT(:,:,2).^2,'all')/nnz(interior.*I);
    rmsm = sqrt(msm);
    errorT = rmse/rmsm;
end


function lgraph = createTracnet_optim2(S, encoder_att, decoder_att, encoder_filters, decoder_filters)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% createTracnet(S, [encoder_att], [decoder_att])
% ��С�Ķ��汾������ע�������ؿ���
% encoder_att: [1��3 logical] ���������׶��Ƿ��ע���� (Ĭ��ȫtrue)
% decoder_att: [1��4 logical] ���������׶��Ƿ��ע���� (Ĭ��ȫtrue)

%% ���������Դ���������ԭ�е��÷�ʽ��
if nargin < 2, encoder_att = true(1,3); end
if nargin < 3, decoder_att = true(1,4); end

if nargin < 4 || isempty(encoder_filters)  % ����Ĭ�ϱ���������
    encoder_filters = [32 64; 64 128; 128 256]; 
end
if nargin < 5 || isempty(decoder_filters)  % ����Ĭ�Ͻ���������
    decoder_filters = [128 256; 64 128; 32 64; 1 32];
end

%% ԭʼ�������ñ��ֲ���
inputSize = [S S 2];
inputLayer = image3dInputLayer(inputSize,'Normalization','none','Name','input');
numFiltersEncoder = encoder_filters;
layers = [inputLayer];

%% �Ľ���1��������ģ������������
encoder_outputs = cell(3,1); % ��¼������������ڵ�
decoder_outputs = cell(4,1);
for module = 1:3
    layer_name = num2str(module);
    encoderModule = [
        convolution3dLayer([3 3 2], numFiltersEncoder(module,1), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['en', layer_name, '_conv1']);
        batchNormalizationLayer('Name', ['en', layer_name, '_bn']);
        reluLayer('Name', ['en', layer_name, '_relu1']);
        convolution3dLayer([3 3 2], numFiltersEncoder(module,2), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['en', layer_name, '_conv2']);
        reluLayer('Name', ['en', layer_name, '_relu2'])
    ];

    %%% ��������ע����ģ�� %%%
    if encoder_att(module)
        encoderModule = [encoderModule;
            globalAveragePooling3dLayer('Name', ['en', layer_name, '_gap']);
            fullyConnectedLayer(numFiltersEncoder(module,2), 'Name', ['en', layer_name, '_fc1']);
            reluLayer('Name', ['en', layer_name, '_relu3']);
            fullyConnectedLayer(numFiltersEncoder(module,2), 'Name', ['en', layer_name, '_fc2']);
            sigmoidLayer('Name', ['en', layer_name, '_sigmoid1']);
            multiplicationLayer(2, 'Name', ['en', layer_name, '_channel_mult']);
            
            convolution3dLayer([3 3 3], 1, 'Padding', 'same', 'Name', ['en', layer_name, '_spatial_conv']);
            sigmoidLayer('Name', ['en', layer_name, '_sigmoid2']);
            multiplicationLayer(2, 'Name', ['en', layer_name, '_spatial_mult'])
        ];
        encoder_outputs{module} = "en" + layer_name + "_spatial_mult"; % �ַ�������
    else
         encoder_outputs{module} = "en" + layer_name + "_relu2"; 
    end

    encoderModule = [encoderModule;
        maxPooling3dLayer([2,2,1], 'Stride', [2,2,1], 'Padding', 'same', ...
            'Name', ['en', layer_name, '_maxpool'])
    ];
    layers = [layers; encoderModule];
end

%% �Ľ���2��������ģ������������
numFiltersDecoder = decoder_filters;
for module = 1:4
    layer_name = num2str(-module+5);
    decodeModule = [
        convolution3dLayer([3 3 2], numFiltersDecoder(module,1), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['de', layer_name, '_conv1']);
        batchNormalizationLayer('Name', ['de', layer_name, '_bn1']);
        reluLayer('Name', ['de', layer_name, '_relu1']);
        convolution3dLayer([3 3 2], numFiltersDecoder(module,2), ...
            'Padding', 'same', 'WeightsInitializer', 'narrow-normal', ...
            'BiasInitializer', 'zeros', 'Name', ['de', layer_name, '_conv2']);
        batchNormalizationLayer('Name', ['de', layer_name, '_bn2']);        
        reluLayer('Name', ['de', layer_name, '_relu2'])
    ];


    %%% �޸��㣺���н���������ǰ׺��Ϊde %%%
    if decoder_att(module)
        decodeModule = [decodeModule;
            globalAveragePooling3dLayer('Name', ['de', layer_name, '_gap']);
            fullyConnectedLayer(numFiltersDecoder(module,2), 'Name', ['de', layer_name, '_fc1']);
            reluLayer('Name', ['de', layer_name, '_relu3']);
            fullyConnectedLayer(numFiltersDecoder(module,2), 'Name', ['de', layer_name, '_fc2']);
            sigmoidLayer('Name', ['de', layer_name, '_sigmoid1']);
            multiplicationLayer(2, 'Name', ['de', layer_name, '_channel_mult']);
            
            convolution3dLayer([3 3 3], 1, 'Padding', 'same', 'Name', ['de', layer_name, '_spatial_conv']);
            sigmoidLayer('Name', ['de', layer_name, '_sigmoid2']);
            multiplicationLayer(2, 'Name', ['de', layer_name, '_spatial_mult'])
        ];
        decoder_outputs{module} = "de" + layer_name + "_spatial_mult"; % �ؼ��޸���
    else
        decoder_outputs{module} = "de" + layer_name + "_relu2"; 
    end

    decodeModule = [decodeModule;
        transposedConv3dLayer([3,3,1], numFiltersDecoder(module,2), 'Stride', [2,2,1], 'Cropping', 'same', ...
            'WeightsInitializer', 'narrow-normal', 'BiasInitializer', 'zeros', ...
            'Name', ['de', layer_name, '_transconv'])
    ];
    
    layers = [layers; decodeModule];
end






lgraph = layerGraph(layers);

lgraph = removeLayers(lgraph, 'de1_transconv');
layer =  convolution3dLayer([3 3 2], 1, ...
            'Padding','same','WeightsInitializer','narrow-normal', ...
            'BiasInitializer', 'zeros', ...
            'Name',['de1_conv3']);
lgraph = addLayers(lgraph,layer);
if decoder_att(4)
   lgraph = connectLayers(lgraph,'de1_spatial_mult','de1_conv3');
else
   lgraph = connectLayers(lgraph,'de1_relu2','de1_conv3');
end
layer = regressionLayer('name','output');
lgraph = addLayers(lgraph,layer);
lgraph = connectLayers(lgraph, 'de1_conv3','output');
for module = 1:3
    
    
     if encoder_att(module)
          layer_name = num2str(module);
          lgraph = connectLayers(lgraph, ['en', layer_name, '_relu2'], ['en', layer_name, '_channel_mult/in2']); 
          lgraph = connectLayers(lgraph, ['en', layer_name, '_channel_mult'], ['en', layer_name, '_spatial_mult/in2']);
     end
  
end

%% �Ľ���4��������ע�����������������޸��棩
for module = 1:4
    layer_name = num2str(-module+5);
    
    % �������ø�ģ���ע����ʱ��ִ������
    if decoder_att(module)
        % 遍历�?有编码器和解码器模块
        %% ͨ��ע��������
        channel_src = ['de', layer_name, '_relu2'];
        channel_dest = ['de', layer_name, '_channel_mult/in2'];
        if ~hasConnection(lgraph, channel_src, channel_dest)
            lgraph = connectLayers(lgraph, channel_src, channel_dest);
        end
        
        %% �ռ�ע��������
        spatial_src = ['de', layer_name, '_channel_mult'];
        spatial_dest = ['de', layer_name, '_spatial_mult/in2'];
        if ~hasConnection(lgraph, spatial_src, spatial_dest)
            lgraph = connectLayers(lgraph, spatial_src, spatial_dest);
        end
    end
end

%% �������������������ļ�ĩβ��
function existFlag = hasConnection(lgraph, src, dest)
% ���ָ�������Ƿ��Ѵ���
   existFlag = any(strcmp(lgraph.Connections.Source, src) & ...
                strcmp(lgraph.Connections.Destination, dest));
end


concat_config = [ % ��Ϊ��ά�ַ�������
    "en1", "concat1/in1", "de2_transconv"; 
    "en2", "concat2/in1", "de3_transconv"; 
    "en3", "concat3/in1", "de4_transconv"
];

for i = 1:3
    % ֱ�Ӱ�����������
    concat_name = concat_config(i,1);
    in_port = concat_config(i,2);
    deconv_layer = concat_config(i,3);
    
    % ͳһʹ���ַ���ƴ��
    lgraph = disconnectLayers(lgraph, deconv_layer, "de" + i + "_conv1");
    concat_layer = concatenationLayer(4,2,'Name',char(concat_name)); % ת��Ϊchar
    lgraph = addLayers(lgraph, concat_layer);
    lgraph = connectLayers(lgraph, encoder_outputs{i}, concat_name + "/in1");
    lgraph = connectLayers(lgraph, deconv_layer, concat_name + "/in2");
    lgraph = connectLayers(lgraph, concat_name + "/out", "de" + i + "_conv1");
end

%% ����ԭʼ���������߼�
analyzeNetwork(lgraph);
fn = sprintf('tracnetGraph%d_AttEnc%d%d%d_Dec%d%d%d%d.mat',S,...
    encoder_att(1),encoder_att(2),encoder_att(3),...
    decoder_att(1),decoder_att(2),decoder_att(3),decoder_att(4));
save(fn,'lgraph');
end





