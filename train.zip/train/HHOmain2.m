% ����һ������ĳ������� cg(1��26)

lb = [1, 1, 1, 1, 1, 1,	1, 7,  32, 64, 116, 101,256, 110, 255, 40, 120, 19,44, 2, 26, 160, 0.00234586, 0.884538233, 0.000530496, 14, 2.1];
ub = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128, 128,256, 128, 256, 64, 128, 32,64, 2, 32, 160,   3e-3,       0.9,       1e-3,        20,   3];

S=104;

% 3. ����ѵ���� augmentedImageDatastore
% --- ע�⣺����������� .mat �ļ���ı������� dspl �� trac
fn_dspl    = sprintf('trainData%d/dspl',S);
fn_dsplR   = sprintf('trainData%d/dsplRadial',S);
fn_trac    = sprintf('trainData%d/trac',S);
fn_tracR   = sprintf('trainData%d/tracRadial',S);
    
dsplDS = imageDatastore({fn_dspl,fn_dsplR},  'FileExtensions','.mat','ReadFcn',@load);
tracDS = imageDatastore({fn_trac,fn_tracR},  'FileExtensions','.mat','ReadFcn',@load);
    
 % Ԥ���䲢����
numTrain = numel(dsplDS.Files);
% numTrain=40;
dspl_array = zeros(S,S,2,numTrain,'single');
trac_array = zeros(S,S,2,numTrain,'single');
for i=1:numTrain
    tmp1 = load(dsplDS.Files{i}); dspl_array(:,:,:,i) = tmp1.dspl;
    tmp2 = load(tracDS.Files{i}); trac_array(:,:,:,i) = tmp2.trac;
end
    
augimdsTrain = augmentedImageDatastore([S S 2], dspl_array, trac_array);

%% 4. ������֤�� augmentedImageDatastore
val_dspl_path = 'C:/Users/admin/Desktop/DL-TFM-main1/test/generic/testData104/dspl/';
val_trac_path = 'C:/Users/admin/Desktop/DL-TFM-main1/test/generic/testData104/trac/';
val_dspl_files = dir(fullfile(val_dspl_path,'MLData*.mat'));
val_trac_files = dir(fullfile(val_trac_path,'MLData*.mat'));
numVal = numel(val_dspl_files);
    
val_dspl_array = zeros(S,S,2,numVal,'single');
val_trac_array = zeros(S,S,2,numVal,'single');
% �������Ҫ�߽����Σ���һ��������
val_brdx = cell(numVal,1);
val_brdy = cell(numVal,1);
    
for i=1:numVal
    tmp1 = load(fullfile(val_dspl_path,  val_dspl_files(i).name));
    tmp2 = load(fullfile(val_trac_path,  val_trac_files(i).name));
    val_dspl_array(:,:,:,i) = tmp1.dspl;
    val_trac_array(:,:,:,i) = tmp2.trac;
    if isfield(tmp2,'brdx'), val_brdx{i} = tmp2.brdx; end
    if isfield(tmp2,'brdy'), val_brdy{i} = tmp2.brdy; end
end
    
augimdsVal = augmentedImageDatastore([S S 2], val_dspl_array, val_trac_array);

if ~hasdata(augimdsVal)
    error('��֤���ݼ�Ϊ�գ��������ݼ���·��');
end
 %% 3��HHO ������
mfgbo_option = struct();
mfgbo_option.SearchAgents_no = 1;    % ӥȺ��С���Ƽ� 5��20
mfgbo_option.Max_iteration    = 1;    % ������������10��50 ����
mfgbo_option.dim              = numel(lb);  % 27
mfgbo_option.lb               = lb;
mfgbo_option.ub               = ub;

%% 4������ HHO_CNN
[BestLocation, CNVG,bestNet] = HHO_CNN( ...
    augimdsTrain, numTrain, ...
    augimdsVal,   numVal, ...
    val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
    mfgbo_option ...
);
save('bestTracNet.mat','bestNet');
% 2. ���浽 .mat �ļ�����ã�
save('HHO_CNN_Result.mat','BestLocation','CNVG');

% 3. ����뵼���� CSV���� writematrix
writematrix(BestLocation,'BestLocation.csv');
writematrix(CNVG,        'CNVG.csv');

function [Rabbit_Location, CNVG, bestNet]=HHO_CNN(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,mfgbo_option)
 %% Initialization

%  if nargin == 4
%     mfgbo_option = struct('SearchAgents_no', 1, 'Max_iteration', 5, 'dim',10, 'lb', low,'ub',up);
%  end
N =mfgbo_option.SearchAgents_no; 
dim = mfgbo_option.dim;
MaxFES = mfgbo_option.Max_iteration;
 
lb = mfgbo_option.lb; 
ub = mfgbo_option.ub;
 %%
disp('HHO is now tackling your problem')
tic
% initialize the location and Energy of the rabbit
Rabbit_Location=zeros(1,dim);
Rabbit_Energy=inf;

fitness1 = inf(N, 1);
%Initialize the locations of Harris' hawks
% X=[1, 1, 1,	1,1,1,1, 18, 34.90709065, 64, 115.5110204,100.3618978,256,	109.7646876, 254.4398195, 39.05623761, 119.7441918, 18.31152282, 43.80191121, 1.412802406, 25.76543722, 200, 0.00234586,	0.884538233, 0.000530496, 14.06898439, 2.106127808];
X=[1,0.70232098,1,1	,1,	1	,0.54321277,	18.13575753,	62.251705,	64,	116	,101	,256,	110,	255.6298701,	40,	121.0347508,	20.95845102	,48.64960038,	2,27.47273783,	158	,0.00234586,	0.88975826,	0.001	,16.597441,	3];
CNVG=[];
% fes=0; % FES counter
t=0; % Loop counter

while t<MaxFES
    disp(['Iteration: ' num2str(t+1) '/' num2str(MaxFES)]);  % Show current iteration
    for i=1:size(X,1)
        % Check boundries
       FU=X(i,:)>ub;
       FL=X(i,:)<lb;
       X(i,:)=(X(i,:).*(~(FU+FL)))+ub.*FU+lb.*FL;
       [fitness, net] = fobj1(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,X,lb,ub);
       fitness1(i)=fitness
%         fes=fes+1
        % Update the location of Rabbit
        if fitness1(i)<Rabbit_Energy
            Rabbit_Energy=fitness1(i);
            Rabbit_Location=X;
            bestNet=net;
        end
    end
   
    t=t+1;
    CNVG(t)=Rabbit_Energy;

end
toc
end


function o=Levy(dim)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,dim)*sigma;v=randn(1,dim);step=u./abs(v).^(1/beta);
o=step;
end

% =========================================================================
% ===                MODIFIED fobj1 FUNCTION (VERSION 2)                ===
% =========================================================================
% Changes:
% 1. Integrated validation directly into trainNetwork using 'ValidationData'.
% 2. The training plot now shows both training and validation loss curves.
% 3. The function returns the network with the 'best-validation-loss',
%    which helps prevent overfitting.
% 4. The fitness value for HHO is now the minimum validation loss achieved
%    during training, which is a more stable metric for optimization.
% 5. Added code to save the training progress plot automatically.
% =========================================================================
function [fitness, net] = fobj1(augimdsTrain, numTrain, augimdsVal, numVal, val_dspl_array, val_trac_array, val_brdx, val_brdy, cg, lb, ub)
    %% 1. ��ʼ���Ͳ������� (��ԭ����ͬ)
    cg = max(min(cg,ub), lb);
    
    % 1.1 attention ���أ�bool��
    encoder_att = logical( cg(1:3) > 0.5 );
    decoder_att = logical( cg(4:7) > 0.5 );
    
    % 1.2 encoder_filters��3��2 ��������
    ef = round( cg(8:13) );
    encoder_filters = reshape(ef, 3, 2);
    
    % 1.3 decoder_filters��4��2 ��������
    df = round( cg(14:21) );
    decoder_filters = reshape(df, 4, 2);
   
    % 1.4 ѵ������
    ep                   = max(1, round(cg(22))); % �����ܵ�ѵ��������
    lr                   = cg(23);
    LearnRateDropFactor  = cg(24);
    L2Regularization     = cg(25);
    LearnRateDropPeriod  = ceil(cg(26));
    solverNum            = ceil(cg(27));

    fprintf('\n--- New HHO Evaluation (Manual Validation Loop) ---\n');
    fprintf('  encoder_att: [%d %d %d]\n', encoder_att);
    fprintf('  decoder_att: [%d %d %d %d]\n', decoder_att);
    fprintf('  encoder_filters: [%d %d; %d %d; %d %d]\n', encoder_filters');
    fprintf('  decoder_filters: [%d %d; %d %d; %d %d; %d %d]\n', decoder_filters');
    fprintf('  total_epochs: %d, lr: %.4g, lr_drop_factor: %.3f, l2_reg: %.4g, lr_drop_period: %d, solver: %d\n', ...
            ep, lr, LearnRateDropFactor, L2Regularization, LearnRateDropPeriod, solverNum);
    
    %% 2. �����볬������ (��ԭ����ͬ)
    S = 104;
    mag = S/104;
    
    solverList  = {'sgdm','adam','rmsprop'};
    solverType = solverList{solverNum};
    
    % ������ʼ����ṹ
    lgraph = createTracnet_optim2(S, encoder_att, decoder_att, ...
                                  encoder_filters, decoder_filters);
                                
    %% 3. ���� minibatch (��ԭ����ͬ)
    MiniBatchSize = ceil(84/mag);

    %% 4. ���õ�����ѵ��ѡ�� (�����޸�)
    % ���Ķ�1�����ǲ����������õ�ѧϰ�ʵ���������Ϊ���ǽ��ֶ���������
    % ��ˣ��� trainingOptions ���Ƴ��� 'LearnRateSchedule', 'LearnRateDropPeriod', 'LearnRateDropFactor'��
    options = trainingOptions(solverType, ...
        'InitialLearnRate',    lr, ... % ���ֵ����ѭ���б���̬����
        'L2Regularization',    L2Regularization, ...
        'MaxEpochs',           1, ...  
        'MiniBatchSize',       MiniBatchSize, ...
        'Shuffle',             'every-epoch', ...
        'GradientThreshold',   1, ...
        'Verbose',             false, ... 
        'Plots',               'none'); 

    %% 5. �ֶ�ѵ������֤ѭ��
    
    bestFitness = Inf; 
    bestNet = [];      
    trainingHistory = []; 

     % ���Ķ�1������һ�����������洢ÿ�����ڵ���֤���
    validationHistory = zeros(ep, 1);

    % ���Ķ�2����ѭ����ʼǰ����ʼ����ǰѧϰ��
    current_lr = lr;

    fprintf('Starting manual training loop for %d epochs...\n', ep);
    
    for current_epoch = 1 : ep
        fprintf('--- Epoch %d/%d (Current LR: %.6g) ---\n', current_epoch, ep, current_lr);
        
        % ���Ķ�3����ÿ��ѵ��ǰ���õ�ǰ��ѧϰ�ʸ��� trainingOptions
        options.InitialLearnRate = current_lr;

        % 5.1 ѵ������һ������
        fprintf('Training...\n');
        [net_epoch, info_epoch] = trainNetwork(augimdsTrain, lgraph, options);
        trainingHistory = [trainingHistory; info_epoch]; 
        
        % 5.2 �ֶ�����֤�������� (�ⲿ���߼�����)
        fprintf('Validating...\n');
        totalErr = 0;
        E = 10670;
        
        for i = 1:numVal
            dsplSample = val_dspl_array(:,:,:,i);
            tracGT     = val_trac_array(:,:,:,i);
            brdx = []; brdy = [];
            if ~isempty(val_brdx{i}), brdx = val_brdx{i}; end
            if ~isempty(val_brdy{i}), brdy = val_brdy{i}; end
        
            pred = predictTrac(net_epoch, dsplSample, E);   
            totalErr = totalErr + errorTrac(pred, tracGT, brdx, brdy);
        end
        
        currentMeanErr = totalErr / numVal;
        fprintf('Epoch %d - Validation Mean Relative Error: %.4f\n', current_epoch, currentMeanErr);
        
        % 5.3 ��鲢�������ģ�� (�ⲿ���߼�����)
        if currentMeanErr < bestFitness
            bestFitness = currentMeanErr;
            bestNet = net_epoch; 
            fprintf('>>> Found new best network! Fitness: %.4f <<<\n', bestFitness);
        end
        
        % 5.4 ���ؼ����衿Ϊ��һ��ѵ��׼������ (�ⲿ���߼�����)
        lgraph = layerGraph(net_epoch);

        % ���Ķ�4�������ڽ����󣬼���Ƿ���Ҫ����ѧϰ�ʣ�Ϊ��һ��������׼��
        % ���Ҫ���� "ÿ��17���½�һ��"
        if mod(current_epoch, LearnRateDropPeriod) == 0
            current_lr = current_lr * LearnRateDropFactor;
            fprintf('>>> Learning rate dropped to %.6g for the next epoch.\n', current_lr);
        end
    end
    
    % �������� (6, 7, 8) ���ֲ���...
    
    %% 6. ȷ�����ս��
    fitness = bestFitness;
    net = bestNet;     
    if isempty(net)
        net = net_epoch;
        fprintf('Warning: No improvement found during training. Returning the network from the last epoch.\n');
    end
    fprintf('\n--- Training Complete ---\n');
    fprintf('�� Best Fitness (Mean Relative Error) found: %.4f\n', fitness);

    %% 7. (��ѡ) �ֶ�����ѵ������
    try
        figure;
        plot([trainingHistory.TrainingLoss]);
        xlabel('Iterations');
        ylabel('Training Loss (RMSE)');
        title('Manual Training Loop - Training Loss Over Iterations');
        grid on;
    catch ME
        fprintf('Could not plot training history: %s\n', ME.message);
    end
    
    %% 8. ��������ģ��
    info_to_save.TrainingHistory = trainingHistory;
    info_to_save.BestFitness = fitness;
    save('tracnet_best_manual_validation.mat', 'net', 'fitness', 'info_to_save');
end


%% Ԥ�⺯�� (�޸ĺ�)
function trac = predictTrac(net, dspl, E)
    S = size(dspl,1);
    mag = S/104;
    conversion = E/10*mag;
    trac = activations(net,dspl,'output')*conversion;
end


function errorT = errorTrac(trac,tracGT,brdx,brdy,varargin)

%% define the region within the cell for calculating the error
warning('off','all');
if nargin==4
    cutoff = 0;
elseif nargin==5
    cutoff = varargin{1};
else
    disp('Error')
end
pgn = polyshape(brdx,brdy);
[ydim,xdim,~] = size(trac);
[X,Y] = meshgrid(1:xdim,1:ydim);
interior = isinterior(pgn,Y(:),X(:));
interior = reshape(interior,ydim,xdim);

trac(:,:,1) = trac(:,:,1).*interior;
trac(:,:,2) = trac(:,:,2).*interior;
tracGT(:,:,1) = tracGT(:,:,1).*interior;
tracGT(:,:,2) = tracGT(:,:,2).*interior;

tracMag = sqrt(trac(:,:,1).^2+trac(:,:,2).^2);
tracGTMag = sqrt(tracGT(:,:,1).^2+tracGT(:,:,2).^2);

if cutoff>0
    threshold = prctile(tracGTMag(interior),cutoff);
    I = tracMag>threshold | tracGTMag>threshold;
    trac(:,:,1) = trac(:,:,1).*I;
    trac(:,:,2) = trac(:,:,2).*I;
    tracGT(:,:,1) = tracGT(:,:,1).*I;
    tracGT(:,:,2) = tracGT(:,:,2).*I;
else
    I = ones(ydim,xdim);
end

mse = sum((trac(:,:,1)-tracGT(:,:,1)).^2 + (trac(:,:,2)-tracGT(:,:,2)).^2,'all')/nnz(interior.*I);
rmse = sqrt(mse);
msm = sum(tracGT(:,:,1).^2+tracGT(:,:,2).^2,'all')/nnz(interior.*I);
rmsm = sqrt(msm);
errorT = rmse/rmsm;

end


