% ����һ������ĳ������� cg(1��26)

lb = [0, 0, 0, 0, 0, 0, 0, 1,  32, 32, 64, 64, 128, 64, 128, 32, 64,  1, 32, 1, 1,  20, 1e-4,0.5, 3e-3, 10, 0.1];
ub = [1, 1, 1, 1, 1, 1, 1, 32, 64, 64, 128,128,256, 128,256, 64, 128, 32,64, 2, 32, 20, 3e-3,0.9, 1e-3,  20,   3];
% cg0 = lb + (ub-lb).*rand(1,27);
S=104;

% 3. ����ѵ���� augmentedImageDatastore
% --- ע�⣺����������� .mat �ļ���ı������� dspl �� trac
fn_dspl    = sprintf('trainData%d/dspl',S);
fn_dsplR   = sprintf('trainData%d/dsplRadial',S);
fn_trac    = sprintf('trainData%d/trac',S);
fn_tracR   = sprintf('trainData%d/tracRadial',S);
    
dsplDS = imageDatastore({fn_dspl,fn_dsplR},  'FileExtensions','.mat','ReadFcn',@load);
tracDS = imageDatastore({fn_trac,fn_tracR},  'FileExtensions','.mat','ReadFcn',@load);
    
 % Ԥ���䲢����
numTrain = numel(dsplDS.Files);
dspl_array = zeros(S,S,2,numTrain,'single');
trac_array = zeros(S,S,2,numTrain,'single');
for i=1:numTrain
    tmp1 = load(dsplDS.Files{i}); dspl_array(:,:,:,i) = tmp1.dspl;
    tmp2 = load(tracDS.Files{i}); trac_array(:,:,:,i) = tmp2.trac;
end
    
augimdsTrain = augmentedImageDatastore([S S 2], dspl_array, trac_array);

%% 4. ������֤�� augmentedImageDatastore
val_dspl_path = 'C:/Users/11066/Desktop/DL-TFM-main1/test/generic/testData104/dspl/';
val_trac_path = 'C:/Users/11066/Desktop/DL-TFM-main1/test/generic/testData104/trac/';
val_dspl_files = dir(fullfile(val_dspl_path,'MLData*.mat'));
val_trac_files = dir(fullfile(val_trac_path,'MLData*.mat'));
numVal = numel(val_dspl_files);
    
val_dspl_array = zeros(S,S,2,numVal,'single');
val_trac_array = zeros(S,S,2,numVal,'single');
% �������Ҫ�߽����Σ���һ��������
val_brdx = cell(numVal,1);
val_brdy = cell(numVal,1);
    
for i=1:numVal
    tmp1 = load(fullfile(val_dspl_path,  val_dspl_files(i).name));
    tmp2 = load(fullfile(val_trac_path,  val_trac_files(i).name));
    val_dspl_array(:,:,:,i) = tmp1.dspl;
    val_trac_array(:,:,:,i) = tmp2.trac;
    if isfield(tmp2,'brdx'), val_brdx{i} = tmp2.brdx; end
    if isfield(tmp2,'brdy'), val_brdy{i} = tmp2.brdy; end
end
    
augimdsVal = augmentedImageDatastore([S S 2], val_dspl_array, val_trac_array);

if ~hasdata(augimdsVal)
    error('��֤���ݼ�Ϊ�գ��������ݼ���·��');
end
 %% 3��HHO ������
mfgbo_option = struct();    
mfgbo_option.SearchAgents_no = 20;    % ӥȺ��С���Ƽ� 5��20
mfgbo_option.Max_iteration    = 50;    % ������������10��50 ����
mfgbo_option.dim              = numel(lb);  % 27
mfgbo_option.lb               = lb;
mfgbo_option.ub               = ub;

%% 4������ HHO_CNN
[BestLocation, CNVG,bestNet] = HHO_CNN( ...
    augimdsTrain, numTrain, ...
    augimdsVal,   numVal, ...
    val_dspl_array, val_trac_array, val_brdx, val_brdy, ...
    mfgbo_option ...
);
save('bestTracNet.mat','bestNet');
% 2. ���浽 .mat �ļ�����ã�
save('HHO_CNN_Result.mat','BestLocation','CNVG');

% 3. ����뵼���� CSV���� writematrix
writematrix(BestLocation,'BestLocation.csv');
writematrix(CNVG,        'CNVG.csv');

function [Rabbit_Location, CNVG, bestNet]=HHO_CNN(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,mfgbo_option)
 %% Initialization

 if nargin == 4
    mfgbo_option = struct('SearchAgents_no', 2, 'Max_iteration', 5, 'dim',10, 'lb', low,'ub',up);
 end
N =mfgbo_option.SearchAgents_no; 
dim = mfgbo_option.dim;
MaxFES = mfgbo_option.Max_iteration;
 
lb = mfgbo_option.lb; 
ub = mfgbo_option.ub;
 %%
disp('HHO is now tackling your problem')
tic
% initialize the location and Energy of the rabbit
Rabbit_Location=zeros(1,dim);
Rabbit_Energy=inf;

fitness1 = inf(N, 1);
%Initialize the locations of Harris' hawks
X=initialization(N,dim,ub,lb);

CNVG=[];
% fes=0; % FES counter
t=0; % Loop counter

while t<MaxFES
    disp(['Iteration: ' num2str(t+1) '/' num2str(MaxFES)]);  % Show current iteration
    for i=1:size(X,1)
        % Check boundries
       FU=X(i,:)>ub;
       FL=X(i,:)<lb;
       X(i,:)=(X(i,:).*(~(FU+FL)))+ub.*FU+lb.*FL;
       [fitness, net] = fobj(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,X(i,:),lb,ub);
       fitness1(i)=fitness
%         fes=fes+1
        % Update the location of Rabbit
        if fitness1(i)<Rabbit_Energy
            Rabbit_Energy=fitness1(i);
            Rabbit_Location=X(i,:);
            bestNet=net;
        end
    end
    
    c=2*(1-(t/MaxFES)); % factor to show the decreaing energy of rabbit
    % Update the location of Harris' hawks
    for i=1:size(X,1)
        Escaping_Energy=c*(2*rand()-1);  % escaping energy of rabbit
        
        if abs(Escaping_Energy)>=1
            %% Exploration:
            % Harris' hawks search for the rabbit, observing the area to find a rabbit
            % Harris' hawks perch randomly based on 2 strategy:
            
            r=rand();
            rand_Hawk_index = floor(N*rand()+1);
            X_rand = X(rand_Hawk_index, :);
            if r<0.5
                % perch based on other family members
                X(i,:)=X_rand-rand()*abs(X_rand-2*rand()*X(i,:));
            elseif r>0.5
                % perch on a random tall tree (random site inside group's home range)
                X(i,:)=(Rabbit_Location(1,:)-mean(X))-rand()*((ub-lb)*rand+lb);
            end
            
        elseif abs(Escaping_Energy)<1
            %% Exploitation:
            % Attacking the rabbit using 4 strategies regarding the behavior of the rabbit
            
            %% phase 1: surprise pounce (seven kills): hawks go to kill when rabbit is surprised
            % surprise pounce (seven kills): multiple, short rapid dives by different hawks
            
            r=rand(); % probablity of each event % r>0.5 : rabbit cannot escape -- r<0.5 : rabbit can escape
            
            if r>0.5 && abs(Escaping_Energy)<0.5 % Hard besiege % When rabbit cannot or do not try to escape
                X(i,:)=(Rabbit_Location)-Escaping_Energy*abs(Rabbit_Location-X(i,:));
            end
            
            if r>0.5 && abs(Escaping_Energy)>0.5  % Soft besiege % When rabbit cannot or do not try to escape
                Jump_strength=2*(1-rand()); % random jump strength of the rabbit
                X(i,:)=(Rabbit_Location-X(i,:))-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));
            end
            
            %% phase 2: performing team rapid dives (leapfrog movements) when prey escapes
            if r<0.5 && abs(Escaping_Energy)>0.5 % Soft besiege % rabbit try to escape by many zigzag deceptive motions
                
                Jump_strength=2*(1-rand());
                X1=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));
                
%                 fes=fes+1 %因为下面已经使用了fobj(X1)，所以就得加1
                [fitness, net]=fobj(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,X1,lb,ub)
                if fitness<fitness1(i) % improved move?
                    X(i,:)=X1;
                else % hawks perform levy-based short rapid dives around the rabbit
                    X2=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:))+rand(1,dim).*Levy(dim);

%                     fes=fes+1;
                    [fitness, net]=fobj(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,X2,lb,ub)
                    if fitness<fitness1(i) % improved move?
                        X(i,:)=X2;
                    end
                end
            end
            
            if r<0.5 && abs(Escaping_Energy)<0.5 % Hard besiege % rabbit try to escape by many zigzag deceptive motions
                % hawks try to decrease their average location with the rabbit
                Jump_strength=2*(1-rand());
                X1=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-mean(X));
                
%                 fes=fes+1
                if fobj(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,X1,lb,ub)<fitness1(i) % improved move?
                    X(i,:)=X1;
                else % Perform levy-based short rapid dives around the rabbit
                    X2=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-mean(X))+rand(1,dim).*Levy(dim);
%                     fes=fes+1;
                    [fitness, net]=fobj(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,X2,lb,ub)
                    if fitness<fitness1(i) % improved move?
                        X(i,:)=X2;
                    end
                end
            end
            %%
        end
    end
   
    t=t+1;
    CNVG(t)=Rabbit_Energy;

end
toc
end

function X=initialization(nP,dim,ub,lb)

    Boundary_no= size(ub,2); % numnber of boundaries

    % If the boundaries of all variables are equal and user enter a signle
    % number for both ub and lb
    if Boundary_no==1
        X=rand(nP,dim).*(ub-lb)+lb;
    end

    % If each variable has a different lb and ub
    if Boundary_no>1
        for i=1:dim
            ub_i=ub(i);
            lb_i=lb(i);
            X(:,i)=rand(nP,1).*(ub_i-lb_i)+lb_i;
        end
    end
end

function o=Levy(dim)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,dim)*sigma;v=randn(1,dim);step=u./abs(v).^(1/beta);
o=step;
end


% function fitness=fobj(trainingImages,trainingLabels,validImages,validLabels,cg,lb,ub)
function [fitness, net]=fobj(augimdsTrain,numTrain,augimdsVal,numVal,val_dspl_array,val_trac_array,val_brdx,val_brdy,cg,lb,ub)
    %% 1. ��ʼ��
    cg = max(min(cg,ub), lb);
    %% 1. �� cg ��ȡ���������
    % 1.1 attention ���أ�bool��
    encoder_att = logical( cg(1:3) > 0.5 );   % 3 �� encoder attention
    decoder_att = logical( cg(4:7) > 0.5 );   % 4 �� decoder attention
    ef = round( cg(8:13) );                   % 6 ����
    encoder_filters = reshape(ef, 3, 2);    % �� [ [f11 f12]; [f21 f22]; [f31 f32] ]
    
    % 1.3 decoder_filters��4��2 ��������
    df = round( cg(14:21) );                  % 8 ����
    decoder_filters = reshape(df, 4, 2);    % �� [ [d11 d12]; ... ; [d41 d42] ]
   
    % 1.4 ѵ������
    ep                   = max(1, round(cg(22)));  % ���� epoch ��1
    lr                   = cg(23);                  % ��ʼѧϰ�ʣ����㣩
    LearnRateDropFactor  = cg(24);                  % ѧϰ���½�����
    L2Regularization     = cg(25);                  % L2 ����ǿ��
    LearnRateDropPeriod  = ceil(cg(26));  % ��ѧϰ�����ڣ����� ��1��
    solverNum   = ceil(cg(27)) ; 

    params.encoder_att        = encoder_att;          % �߼��� 1��3
    params.decoder_att        = decoder_att;          % �߼��� 1��4
    params.encoder_filters    = encoder_filters;      % ���� 3��2
    params.decoder_filters    = decoder_filters;      % ���� 4��2
    params.epochs             = ep;                   % ������
    params.learning_rate      = lr;                   % ������
    params.lr_drop_factor     = LearnRateDropFactor;  % ������
    params.l2_reg             = L2Regularization;     % ������
    params.lr_drop_period     = LearnRateDropPeriod;  % ����
    params.solver_number      = solverNum;            % ����
        % �������������� fprintf ���
    fprintf('\nѵ���������飺\n');
    fprintf('  encoder_att: [%s]\n', num2str(params.encoder_att));
    fprintf('  decoder_att: [%s]\n', num2str(params.decoder_att));
    fprintf('  encoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d]\n', params.encoder_filters');
    fprintf('  decoder_filters:\n');
    fprintf('    [%d %d; %d %d; %d %d; %d %d]\n', params.decoder_filters');
    fprintf('  epochs: %d\n', params.epochs);
    fprintf('  learning rate: %.4g\n', params.learning_rate);
    fprintf('  lr drop factor: %.4g\n', params.lr_drop_factor);
    fprintf('  L2 regularization: %.4g\n', params.l2_reg);
    fprintf('  lr drop period: %d\n', params.lr_drop_period);
    fprintf('  solver number: %d\n', params.solver_number);
    %% 2. �����볬������
    S = 104;
%     encoder_att  = [true, true, true];
%     decoder_att  = [true, true, true, false];
%     encoder_filters = [32 64; 64 128; 128 256];
%     decoder_filters = [128 256; 64 128; 32 64; 1 32];
%      'ValidationData',      augimdsVal, ...
%             'ValidationFrequency', valFreq, ...
%     
    
%     ep = 2;           % ��� epoch
%     lr = 3e-3;        % ��ʼѧϰ��
   mag = S/104;
%     LearnRateDropFactor=0.7943;
%     L2Regularization=5e-4;
%     LearnRateDropPeriod=10;
%     solverNum   = 2;          % �û�ֻ����������ֵ
%     
    solverList  = {'sgdm','sgdm','sgdm'};
    
    solverType = solverList{solverNum};
    lgraph = createTracnet_optim2(S, encoder_att, decoder_att, ...
                                  encoder_filters, decoder_filters);

    
    %% 5. ���� minibatch ����֤Ƶ��
    numTrainFiles = numTrain;  
    MiniBatchSize      = ceil(20/mag);
    valFreq            = ceil(numTrainFiles/MiniBatchSize);


    switch lower(solverType)
       case 'sgdm'
           options = trainingOptions('sgdm', ...
                'InitialLearnRate',    lr, ...
                'LearnRateSchedule',   'piecewise', ...
                'LearnRateDropPeriod', LearnRateDropPeriod, ...
                'LearnRateDropFactor', LearnRateDropFactor, ...
                'L2Regularization',    L2Regularization, ...
                'MaxEpochs',           ep, ...
                'MiniBatchSize',       MiniBatchSize, ...
                'Shuffle',             'every-epoch', ...
                'GradientThreshold',   1, ...
                'VerboseFrequency',    2 ,...
                'Plots','training-progress');
    
      case 'adam'
          options = trainingOptions('adam', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'VerboseFrequency',    2);
    
      case 'rmsprop'
            options = trainingOptions('rmsprop', ...
            'InitialLearnRate',    lr, ...
            'LearnRateSchedule',   'piecewise', ...
            'LearnRateDropPeriod', LearnRateDropPeriod, ...
            'LearnRateDropFactor', LearnRateDropFactor, ...
            'L2Regularization',    L2Regularization, ...
            'MaxEpochs',           ep, ...
            'MiniBatchSize',       MiniBatchSize, ...
            'Shuffle',             'every-epoch', ...
            'GradientThreshold',   1, ...
            'VerboseFrequency',    2);
    
    
      otherwise
        error('Unsupported solver type: %s', solverType);
    end
%     parpool(2); % ��������������

%     spmd
%         gpuIndex = spmdIndex; % ÿ�������߷��䲻ͬ��GPU
%         gpuDevice(gpuIndex); % ѡ��GPU
    
        % ���ݲ���ѵ��
     [net, info] = trainNetwork(augimdsTrain, lgraph, options);
%     end
    %% 7. ��ʼѵ��
%     [net, info] = trainNetwork(augimdsTrain, lgraph, options);
    
    %% 8. ��ѵ���õ������� net ����֤������һ����������
    totalErr = 0;
    E = 10670;    % �� predictTrac �б���һ�µ��������
    
    for i=1:numVal
        dsplSample = val_dspl_array(:,:,:,i);
        tracGT     = val_trac_array(:,:,:,i);
        brdx       = [];
        brdy       = [];
        if ~isempty(val_brdx{i}), brdx = val_brdx{i}; end
        if ~isempty(val_brdy{i}), brdy = val_brdy{i}; end
    
        pred = predictTrac(net, dsplSample, E);
        % ���û���ṩ�߽磬����ֱ�� errorTrac(pred,tracGT)��
        % ����� brdx,brdy ����ȥ�� interior masking
        totalErr = totalErr + errorTrac(pred, tracGT, brdx, brdy);
    end
    
    meanErr = totalErr / numVal;
    fprintf('�� ����ģ������֤���ϵ�ƽ������� %.4f\n', meanErr);
    fitness=meanErr;
    %% 9. ��������ģ��
    save('tracnet_final.mat','net','meanErr');
end
%% Ԥ�⺯�� (�޸ĺ�)
function trac = predictTrac(net, dspl, E)
    S = size(dspl,1);
    mag = S/104;
    conversion = E/10*mag;
    trac = activations(net,dspl,'output')*conversion;
end


function errorT = errorTrac(trac,tracGT,brdx,brdy,varargin)

%% define the region within the cell for calculating the error
warning('off','all');
if nargin==4
    cutoff = 0;
elseif nargin==5
    cutoff = varargin{1};
else
    disp('Error')
end
pgn = polyshape(brdx,brdy);
[ydim,xdim,~] = size(trac);
[X,Y] = meshgrid(1:xdim,1:ydim);
interior = isinterior(pgn,Y(:),X(:));
interior = reshape(interior,ydim,xdim);

trac(:,:,1) = trac(:,:,1).*interior;
trac(:,:,2) = trac(:,:,2).*interior;
tracGT(:,:,1) = tracGT(:,:,1).*interior;
tracGT(:,:,2) = tracGT(:,:,2).*interior;

tracMag = sqrt(trac(:,:,1).^2+trac(:,:,2).^2);
tracGTMag = sqrt(tracGT(:,:,1).^2+tracGT(:,:,2).^2);

if cutoff>0
    threshold = prctile(tracGTMag(interior),cutoff);
    I = tracMag>threshold | tracGTMag>threshold;
    trac(:,:,1) = trac(:,:,1).*I;
    trac(:,:,2) = trac(:,:,2).*I;
    tracGT(:,:,1) = tracGT(:,:,1).*I;
    tracGT(:,:,2) = tracGT(:,:,2).*I;
else
    I = ones(ydim,xdim);
end

mse = sum((trac(:,:,1)-tracGT(:,:,1)).^2 + (trac(:,:,2)-tracGT(:,:,2)).^2,'all')/nnz(interior.*I);
rmse = sqrt(mse);
msm = sum(tracGT(:,:,1).^2+tracGT(:,:,2).^2,'all')/nnz(interior.*I);
rmsm = sqrt(msm);
errorT = rmse/rmsm;

end


